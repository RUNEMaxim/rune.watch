# Eigene Memoless-Instanz — nur „maxim" im Memo

Ziel: Swaps über rune.watch registrieren ihren Memo bei **deiner** Instanz statt bei `api.thorchain.org`. Dort hängt niemand `uws` an. Fällt deine Instanz aus, weicht der Worker automatisch auf den öffentlichen Dienst aus. Swaps funktionieren also immer, `uws` steht dann nur im Notfall im Memo.

Alles geht vom Handy aus. Rechne mit etwa 30 Minuten.

**Laufende Kosten:** rund 5 $ im Monat für den Server (Railway), dazu 0,02 RUNE pro Swap aus deiner Gebühren-Wallet.

---

## 1 · Repository kopieren (GitHub)

1. Öffne `github.com/familiarcow/thorchain-memoless-api`.
2. Tippe auf **Fork** und dann auf **Create fork**. Du hast jetzt eine eigene Kopie unter deinem Konto.

## 2 · Zugangsschutz einbauen (GitHub)

Ohne diesen Schritt könnte jeder, der die Adresse deiner Instanz findet, auf deine Kosten Memos registrieren und deine Gebühren-Wallet leeren.

1. Öffne in **deinem Fork** die Datei `src/app.ts` und tippe auf den Stift (Bearbeiten).
2. Suche die Zeile `// Rate limiting` und füge **direkt darüber** ein:

```ts
    // Behind a hosting proxy every request otherwise shares the proxy's IP.
    if (process.env.TRUST_PROXY) {
      this.app.set('trust proxy', Number(process.env.TRUST_PROXY) || process.env.TRUST_PROXY);
    }

```

3. Suche die Zeile `this.app.use(limiter);` und füge **direkt darunter** ein:

```ts

    // Optional API key: if API_KEY is set, every /api request must send it
    // in the "x-api-key" header. /health stays open.
    const apiKey = process.env.API_KEY;
    if (apiKey) {
      this.app.use('/api', (req, res, next) => {
        if (req.get('x-api-key') === apiKey) return next();
        res.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Missing or invalid API key' } });
      });
    }
```

4. Tippe auf **Commit changes**.

> Getestet: Der Build läuft durch. Ohne oder mit falschem Schlüssel antwortet die Instanz mit `401`, mit dem richtigen Schlüssel läuft die Anfrage durch.
>
> **Tipp:** FamiliarCow hat angeboten, Änderungen zu übernehmen. Schick ihm die Datei `memoless-api-key.patch` als Pull Request. Ist sie übernommen, kannst du künftig direkt sein Repository verwenden und brauchst diesen Schritt nicht mehr.

## 3 · Gebühren-Wallet anlegen

1. Lege in einer Wallet-App (z. B. Vultisig, Keplr oder Asgardex) eine **neue** THORChain-Wallet an und notiere die 12 oder 24 Wörter.
2. **Nimm niemals deine Haupt-Wallet.** Die Wörter liegen später auf dem Server. In diese Wallet kommt nur das Geld für Gebühren.
3. Noch nichts einzahlen, erst die Adresse aus Schritt 5 abwarten.

## 4 · Server einrichten (Railway)

1. Öffne `railway.com` und melde dich mit **GitHub** an.
2. Tippe auf **New Project**, dann auf **Deploy from GitHub repo** und wähle deinen Fork `thorchain-memoless-api`.
3. Öffne im Dienst den Reiter **Variables** und lege diese an:

| Variable | Wert |
|---|---|
| `THORCHAIN_NETWORK` | `mainnet` |
| `INJECT_AFFILIATE_IN_SWAPS` | `false` |
| `HOT_WALLET_MNEMONIC` | deine 12/24 Wörter aus Schritt 3, mit Leerzeichen dazwischen |
| `API_KEY` | eine lange Zufallsfolge, z. B. 40 Zeichen aus einem Passwort-Generator |
| `TRUST_PROXY` | `1` |
| `RATE_LIMIT` | `300` |
| `CORS_ORIGINS` | `https://runewatch.org` |

   `NODE_ENV` legst du **nicht** an. Mit `NODE_ENV=production` überspringt npm beim Bauen TypeScript, und der Build bricht ab.

   `DATABASE_URL` legst du ebenfalls **nicht** an. rune.watch braucht keine Datenbank, weil die Vorprüfung direkt bei THORChain nachfragt.

4. Öffne den Reiter **Settings**, dann **Networking**, und tippe auf **Generate Domain**. Notiere die Adresse, z. B. `memoless-production-ab12.up.railway.app`.
5. Railway baut und startet den Dienst selbst. Das dauert ein bis zwei Minuten.

   **Falls „error deploying from source“ erscheint:** Prüfe, ob `package.json` direkt oben im Repository liegt. Liegt es in einem Unterordner, trag diesen unter **Settings → Source → Add Root Directory** ein.

## 5 · Prüfen und Wallet füllen

1. Öffne im Browser `https://DEINE-DOMAIN/health`.
2. Unter `wallet` → `address` steht eine `thor1…`-Adresse. **An genau diese Adresse** schickst du etwa **10 RUNE**. Das reicht für rund 500 Swaps.
3. Lade `/health` nach ein paar Minuten neu. Die Wallet sollte als bereit erscheinen.

## 6 · Worker umstellen (Cloudflare)

1. Öffne im Cloudflare-Dashboard den Worker `rune-rewards-backend`, dann **Settings** und **Variables and Secrets**.
2. Lege zwei Einträge an, **beide vom Typ „Secret"**:

| Name | Wert |
|---|---|
| `MEMOLESS_UPSTREAM` | `https://DEINE-DOMAIN/api/v1` |
| `MEMOLESS_API_KEY` | derselbe Wert wie `API_KEY` in Railway |

   Warum „Secret" auch für die Adresse? Du deployst den Worker über GitHub. Klartext-Variablen aus dem Dashboard können dabei überschrieben werden, Secrets nicht.

3. Deploye die neue `worker.js`. Sie enthält die Umstellung samt Rückfall.

## 7 · Endkontrolle

1. Mach einen kleinen Test-Swap über rune.watch.
2. Öffne `https://gateway.liquify.com/chain/thorchain_midgard/v2/actions?affiliate=maxim&limit=1`.
3. Im `memo` muss jetzt **`…::maxim:0`** stehen, ohne `uws`.

Steht dort doch `maxim/uws`, hat der Worker auf den öffentlichen Dienst ausgewichen. Häufigste Ursachen sind ein Tippfehler in `MEMOLESS_UPSTREAM` (`/api/v1` am Ende vergessen?), unterschiedliche Schlüssel in Railway und Cloudflare oder eine leere Gebühren-Wallet. Railway zeigt im Reiter **Deployments** unter **Logs**, ob Anfragen ankommen.

---

## Laufender Betrieb

- **Wallet-Stand:** Schau ab und zu unter `/health` nach. Bei 0,02 RUNE pro Swap sinkt er langsam. Fällt er unter 0,02 RUNE, schlägt die Registrierung fehl, und der Worker weicht automatisch auf den öffentlichen Dienst aus. Swaps laufen dann weiter, nur wieder mit `uws`.
- **Zurück zum öffentlichen Dienst:** Lösche in Cloudflare `MEMOLESS_UPSTREAM`. Der Worker nutzt dann wieder `api.thorchain.org`.
- **Sicherheit:** Auf dem Server liegt nur die Gebühren-Wallet. Nutzergeld läuft nie über sie, die Einzahlungen gehen direkt an THORChain-Vaults. Im schlimmsten Fall ist das verloren, was in dieser Wallet liegt.
