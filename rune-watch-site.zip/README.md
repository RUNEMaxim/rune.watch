# Änderungen in diesem Paket

Reine Frontend-Änderungen an `app.js` und `index.html`. **Kein Worker-, kein D1-, kein
Deploy-Schritt nötig** — einfach die Dateien austauschen.

---

## 1. Handy: man musste im Preis- und Vergleichschart scrollen, um die Indikatoren zu sehen

**Problem:** Drei Ursachen wirkten zusammen.

1. *Die Chart-Höhe war geschätzt statt gemessen.* Beide Hochkant-Modals leiteten `fillToHeight`
   aus einer Konstante ab (`window.innerHeight - 160` bzw. `- 260`). Diese eine Zahl musste
   Kopfzeile, Preiszeile, Karten-Innenabstände, Fußzeile UND die gerätespezifische Safe-Area
   gleichzeitig treffen. `env(safe-area-inset-*)` ist reines CSS und lässt sich aus JavaScript
   gar nicht auslesen — auf jedem Handy mit anderer Notch/Adressleiste lag die Schätzung
   zwangsläufig daneben. Lag sie zu niedrig, wurde der Inhalt höher als die Karte und die
   Modal-Karte (`overflow: auto`) scrollbar.
2. *Die Indikator-Panels hatten eine feste Höhe.* RSI, MACD und Stochastic belegten je fest
   84 px. Bei zwei oder drei gleichzeitig aktiven Panels passte die Summe aus Hauptchart,
   Werkzeugleisten und Panels schlicht nicht mehr in den verfügbaren Platz.
3. *Die 120-px-Untergrenze des Hauptcharts.* Genau diese Grenze griff bei knappem Platz und
   machte den Chart größer als den tatsächlich vorhandenen Raum.

**Fix:**

- Neuer Hook `useMeasuredContentHeight()` (oben in `app.js`): misst die real verfügbare
  Content-Höhe per `clientHeight` + `ResizeObserver`. `clientHeight` ist bereits abzüglich
  sämtlichen Paddings inklusive aller `env(safe-area-*)`-Anteile — die Schätzung entfällt
  komplett. Bewusst ein **Callback-Ref**, weil der gemessene Wrapper einen `key` trägt, der
  sich beim Wechsel von Intervall/Coin ändert (Remount); ein klassisches `useRef` ließe den
  ResizeObserver auf dem alten, abgehängten Element sitzen. Dasselbe Muster wird für den
  Querformat-Vollbild-Chart bereits erfolgreich verwendet (`landscapeContentH`).
- Beide Hochkant-Modals sind im Vollbild-Modus jetzt senkrechte Flexboxen: Kopfbereich und
  Fußzeile behalten ihre natürliche Höhe, der Chart-Bereich bekommt per `flex: 1 1 auto` genau
  den Rest. `minHeight: 0` hebt dabei die `.tp-chart-card { min-height }`-Regel aus
  `index.html` auf, die das Schrumpfen sonst blockieren würde.
- Panel-Höhen sind adaptiv (`subPanelHeight`): mehrere aktive Panels teilen sich den übrigen
  Platz (84 px bis minimal 40 px), dem Hauptchart bleiben mindestens 32 % der Gesamthöhe
  reserviert. Bei nur einem aktiven Panel oder auf dem Desktop bleibt es bei den bisherigen
  84 px — dort ändert sich optisch nichts.
- Die Untergrenze des Hauptcharts skaliert mit dem verfügbaren Platz (höchstens 120 px, nie
  mehr als 30 % davon) statt fest 120 px zu sein.

**Bewusst unverändert:** Im Desktop-Modus (Fensterbreite ≥ 900 px) bleibt die bisherige
Schätzung. Dort hat die Modal-Karte keine feste Höhe — ein `flex: 1`-Kind bekäme nur seine
eigene Inhaltshöhe zurück, das Messen würde sich selbst füttern (Rückkopplung).

**Betroffene Dateien:** `app.js`

---

## 2. MacBook: Zoomen im Chart mit dem Trackpad ging nicht

**Problem:** In `handleWheel()` stand `if (!e.ctrlKey) return;`. Das war ein früherer Fix gegen
„Seite lässt sich über dem Chart nicht mehr scrollen". Die Annahme dahinter — eine echte
Trackpad-Kneif-Geste erzeuge immer ein Wheel-Event mit `ctrlKey: true` — gilt aber **nur für
Chrome und Firefox**. Safari meldet eine Kneif-Geste stattdessen über seine eigenen,
nicht standardisierten Events `gesturestart` / `gesturechange` / `gestureend`, die im Code
nirgends behandelt wurden. In Safari kam dadurch überhaupt kein Zoom-Event an — der Chart ließ
sich dort per Trackpad schlicht gar nicht zoomen. Zusätzlich wurde `metaKey` (Cmd + Mausrad,
auf dem Mac die naheliegendste Tastenkombination) ignoriert und waagerechtes Wischen (`deltaX`)
gar nicht ausgewertet.

**Fix:**

- Listener für `gesturestart` / `gesturechange` / `gestureend` auf dem Chart-SVG. `e.scale` ist
  dort der kumulierte Faktor seit Gestenbeginn; daraus wird pro Event der Schritt-Faktor
  gebildet, damit dieselbe Zoom-Mechanik wie beim Mausrad genutzt werden kann. In Chrome und
  Firefox existieren diese Events nicht — die Listener bleiben dort stumm, keine
  Doppel-Behandlung.
- `metaKey` zählt jetzt wie `ctrlKey` als Zoom-Geste.
- Waagerechtes Zwei-Finger-Wischen (`deltaX`, bzw. Shift+Mausrad) verschiebt den sichtbaren
  Ausschnitt. Kollidiert bewusst nicht mit dem senkrechten Seiten-Scrollen.
- Die Zoom-Mechanik wurde in `applyZoomAtPoint()` herausgezogen und wird jetzt von Mausrad,
  Safari-Gesten und den +/− Knöpfen gemeinsam genutzt.

**Bewusst unverändert:** Senkrechtes Scrollen ohne Zusatztaste wird weiterhin nicht abgefangen
(kein `preventDefault`) — Seite und Modal hinter dem Chart scrollen ganz normal. Genau dafür
gab es die ursprüngliche `ctrlKey`-Prüfung, das Verhalten bleibt erhalten.

**Betroffene Dateien:** `app.js`

---

## 3. Nebenbefund: MACD und Stochastic stürzten ab (nicht gemeldet, beim Prüfen gefunden)

**Problem:** `MACD_HEIGHT`, `MACD_PAD`, `STOCH_HEIGHT`, `macdYScale` und `stochYScale` wurden im
JSX der beiden Panels verwendet, waren aber **nirgends im Code definiert**. Ein Klick auf
„MACD" oder „Stochastic" im Indikator-Menü löste `ReferenceError: macdYScale is not defined`
aus und riss über die ErrorBoundary den kompletten Chart mit. Zwei der acht Indikatoren waren
damit gar nicht benutzbar — unabhängig vom Scroll-Problem.

**Fix:** Beide Skalen implementiert.

- **MACD:** symmetrisch um die Null-Linie, Wertebereich richtet sich nach dem größten
  Absolutwert (MACD-Linie, Signal-Linie oder Histogramm) im *sichtbaren* Ausschnitt — genau wie
  beim RSI-Panel, damit das Panel beim Zoomen/Verschieben mitläuft. Keine feste Skala, weil der
  Wertebereich hier eine Preisdifferenz ist und je nach Coin/Zeitraum um Größenordnungen
  variiert. Einzelne Ausreißer werden auf den Panel-Rand geklemmt (wie `rsiClampY`), statt durch
  `overflow: hidden` unsichtbar zu verschwinden.
- **Stochastic:** fester 0–100-Bereich wie RSI, inkl. der üblichen 20/80-Referenzlinien.
- Beide teilen sich die adaptive Panel-Höhe aus Punkt 1, damit die drei Panels optisch gleich
  hoch sind.

**Betroffene Dateien:** `app.js`

---

## 4. Start-Ablauf: Marken-Ladebildschirm mit rotierendem Blitz

**Problem:** Der bisherige Ladebildschirm war ein generischer grauer Ring — und er stand
**innerhalb von `#root`**. Das war der eigentliche Konstruktionsfehler: React ersetzt beim
Mounten den kompletten Inhalt von `#root`. Der Ring verschwand also exakt in dem Moment, in dem
React zum ersten Mal rendert — noch bevor irgendeine Zahl geladen war. Danach sah man ein bis
zwei Sekunden lang ein leeres bzw. halb gefülltes Gerüst, das sich stückweise füllte.

**Fix — der Ladebildschirm selbst (`index.html`):**

- Neues Element `#tp-boot-splash` als **Geschwister von `#root`**, nicht als Kind. Dadurch kann
  es über dem bereits gerenderten, aber noch leeren Dashboard liegen bleiben, bis `app.js` es
  über `window.__tpHideBootSplash()` freigibt.
- Steht direkt im HTML (nicht in React), ist also im **allerersten Frame** sichtbar — noch bevor
  React, ReactDOM und `app.js` geladen sind. Die Theme-Variablen sind zu dem Zeitpunkt bereits
  gesetzt (Inline-Script im `<head>`), Hell-/Dunkelmodus stimmt von Anfang an.
- Motiv: das Marken-Auge (identische Pfaddaten wie `IconBoltLogo` in `app.js`) mit dem **Blitz
  als rotierender Pupille**, dazu ein heller Bogen, der auf dem Augenumriss umläuft.
  `pathLength="100"` normiert dabei die Kurvenlänge, dadurch lässt sich die Strichelung in
  Prozent angeben, ohne die renderer-abhängige Bezier-Länge kennen zu müssen.
- Drehpunkt über `transform-box: view-box` + `transform-origin: 50px 50px` — also exakt der
  Augenmittelpunkt. Ohne `transform-box` wäre der Drehpunkt browserabhängig die Bounding-Box des
  Pfades, der Blitz würde sichtbar auswandern statt an Ort und Stelle zu rotieren.
- **Nachgerechnet:** unskaliert reicht der Blitz bis Radius 19,53 um den Mittelpunkt, die
  Innenkante des Augenstrichs liegt aber schon bei 17,90 — in der senkrechten Drehlage hätten
  die Spitzen sichtbar über den Umriss hinausgeragt. Mit `scale(0.82)` bleiben rund 1,9
  Einheiten Abstand in **jeder** Drehlage.
- `prefers-reduced-motion` wird berücksichtigt: kein Drehen, kein Umlauf, nur eine ruhige
  Helligkeitspulsation.

**Fix — wann das Dashboard erscheint (`app.js`):**

Freigegeben wird, sobald **entweder** die Daten da sind (`hasData` und ein Preis) **oder** der
erste `fetchPortfolio()`-Durchlauf abgeschlossen ist (neues Flag `firstFetchSettled`). Der
zweite Fall deckt den Fehlerfall ab: scheitern alle Abrufe, bleibt `hasData` false und
stattdessen erscheint das Fehler-Banner — auch das ist ein fertiger Endzustand, es kommt nichts
mehr nach. Das Flag wird am Ende von `fetchPortfolio()` gesetzt, einer Stelle, die dank
`Promise.allSettled` immer erreicht wird.

Zwei Zeitgrenzen rahmen das ein:

- `BOOT_MIN_MS` (620 ms) — Mindestanzeigedauer. Bei warmem Cache wären die Daten nach ~150 ms
  da; der Ladebildschirm würde nur kurz aufblitzen, was unruhiger wirkt als gar keiner. Die
  Zeit läuft ab dem Mount parallel zu den Abrufen, kostet im Normalfall also nichts.
- `BOOT_MAX_MS` (4000 ms) — Notbremse. Ohne sie hinge jemand mit sehr schlechter oder ganz
  fehlender Verbindung unbegrenzt auf dem Ladebildschirm fest und käme nie an die Oberfläche
  (die ohne Netz durchaus nutzbar ist: Einstellungen, gespeicherte Werte).

Dazu ein **zweites, unabhängiges Sicherheitsnetz in `index.html`** (12 s): lädt `app.js` gar
nicht erst (404, blockiert, Syntaxfehler) oder stürzt es beim Mounten ab, darf der
Ladebildschirm nicht dauerhaft stehen bleiben und die Meldung der ErrorBoundary verdecken.

**Fix — die Einblendung:**

- Die fünf Dashboard-Abschnitte gleiten zeitlich versetzt von unten herein (40 ms Versatz je
  Abschnitt, 0,62 s Dauer, insgesamt rund 0,78 s). Ab dem neunten Element wird nicht weiter
  gestaffelt, damit es bei wachsendem Inhalt nicht zäh wird.
- Das Ausblenden des Ladebildschirms ist um **zwei Frames** verzögert (`requestAnimationFrame`
  doppelt verschachtelt): React hat nach dem Commit zwar das DOM aktualisiert, der Browser hat
  den neuen Zustand aber noch nicht gezeichnet. Ohne diesen Puffer beginnt die Überblendung
  über ein noch altes Bild — das Dashboard erschiene erst mitten in der Überblendung.
- Das Dashboard ist bis zur Freigabe auf `opacity: 0`, damit während der Überblendung nichts
  Halbfertiges durchscheint.

**Fallstrick, der dabei entschärft werden musste:** Die Einblendung arbeitet mit `transform`,
und ein Element mit einem `transform`-Wert ungleich `none` wird zum **Bezugsrahmen für
`position: fixed`-Nachfahren**. Die Modals (Charts, Swap, …) sind direkte Geschwister der
Dashboard-Abschnitte — ein Chart, den man innerhalb der knappen Sekunde antippt, hätte sich am
Container statt am Bildschirm ausgerichtet und sichtbar falsch gesessen. Zwei Absicherungen:
die Klasse `.tp-app-enter` wird nach Ablauf der Animation entfernt, **und** zusätzlich sofort,
sobald `anyModalOpen` true wird.

**Betroffene Dateien:** `index.html`, `app.js`

---

## 5. iPhone mit Notch: Logo und Schriftzug lagen unter der Statusleiste

**Problem (mit Screenshot vom iPhone 12 Pro gemeldet):** Der Kopfbereich — Auge, „RUNE.WATCH"
und „POWERED BY MAXIM" — wurde teilweise in den Bereich der iOS-Statusleiste (Uhrzeit, Empfang,
Akku) gezeichnet. Die Oberkante des Logos lag bei rund 32px, die Statusleiste reicht auf diesem
Gerät aber bis 47pt.

**Ursache:** Die Seite meldet sich bewusst als randlos an — `viewport-fit=cover` im
Viewport-Meta-Tag und `apple-mobile-web-app-status-bar-style: black-translucent`. Der Inhalt
beginnt dadurch bei y=0, also *unter* Notch und Statusleiste. Das ist so gewollt (der
Seitenhintergrund soll bis an die Gerätekante reichen), setzt aber voraus, dass der eigentliche
Inhalt über `env(safe-area-inset-*)` wieder nach innen gerückt wird.

Genau dieser Ausgleich fehlte auf der Hauptseite: dort standen feste `16px 20px 32px` ohne jeden
Safe-Area-Anteil. Auf einem Gerät ohne Aussparung (Desktop, ältere iPhones, Android ohne Notch)
fiel das nie auf, weil `env(...)` dort 0 liefert — auf einem iPhone 12 Pro im Homescreen-Modus
sind es dagegen rund 47px, die schlicht fehlten.

Bemerkenswert: die **Modals rechneten bereits korrekt** mit `env(safe-area-inset-*)` (siehe die
`paddingTop`/`paddingBottom`-Berechnungen beim RUNE-Preis- und beim Vergleichs-Modal, sowie beim
Querformat-Vollbild). Nur die Hauptseite selbst war dabei übersehen worden.

**Fix:** Die Seitenhülle rechnet jetzt auf allen vier Seiten mit den Safe-Area-Werten —
links/rechts wegen der abgerundeten Ecken und des Querformats (dort sitzt die Notch seitlich),
unten wegen des Home-Indikators. Entscheidend ist dabei `max()` statt `calc(A + B)`:

```
paddingTop:    max(16px, env(safe-area-inset-top,    0px))   /* 32px auf breiten Bildschirmen */
paddingRight:  max(20px, env(safe-area-inset-right,  0px))
paddingBottom: max(32px, env(safe-area-inset-bottom, 0px))
paddingLeft:   max(20px, env(safe-area-inset-left,   0px))
```

Der Unterschied ist genau der Leerraum, der in einer ersten Fassung beanstandet wurde
(„ich will keine safe areas, das sieht nicht gut aus, wenn ein schwarzer Rand zu sehen ist"):

| | iPhone 12 Pro | iPhone SE (kein Notch) |
|---|---|---|
| `calc(16px + env(...))` | 16 + 47 = **63px** — Grundabstand wird aufgeschlagen | 16 + 0 = 16px |
| `max(16px, env(...))` | max(16, 47) = **47px** — Inhalt exakt an der Kante | max(16, 0) = 16px |

Mit `max()` beginnt der Inhalt also **genau dort, wo der bespielbare Bereich anfängt** — kein
einziger Pixel zusätzlich. Auf Geräten ohne Aussparung greift der Grundabstand von 16px, dort
ist alles exakt wie vor sämtlichen Änderungen.

**Es entsteht dabei kein schwarzer Rand.** Der Hintergrund der Seitenhülle (Verlauf +
`--rw-bg-page`) wird über die gesamte Polsterung mitgemalt, die Hülle ist `min-height: 100vh`.
Der Verlauf läuft also durchgehend bis unter die Statusleiste — reserviert wird nur die
*Position des Inhalts*, nicht die Fläche. Der Test prüft beides explizit mit.

**Ganz weglassen geht nicht:** ohne diese Zeilen liegt der Schriftzug wieder unter Uhrzeit und
Akku — genau der ursprünglich gemeldete Fehler. Und ein fester Zahlenwert statt `env()` wäre auf
allen Geräten außer genau einem falsch (siehe Gerätematrix unten).

**Nicht die Ursache (geprüft):** Die Breite war nie das Problem. Bei 390px Displaybreite stehen
350px zur Verfügung, der Kopfbereich braucht 238px (Logo 58 + Abstand 12 + Schriftzug 128 +
Abstand 8 + Zahnrad 32). Es ging ausschließlich um die vertikale Position.

**Betroffene Dateien:** `app.js`

---

## 6. Kleinigkeit: Bedienhinweis `scrollToZoom` korrigiert

Die Übersetzung „Scrollen zum Zoomen, Ziehen zum Verschieben" (10 Sprachen) existiert im Code,
wird aber **nirgends im UI angezeigt** — der Aufruf fehlt. Nach Punkt 2 wäre der Text zudem
falsch (normales Scrollen zoomt bewusst nicht). Wortlaut auf „Kneifen oder Strg+Scrollen zum
Zoomen, Ziehen zum Verschieben" angepasst, damit er nicht in die Irre führt, falls er später
einmal eingebunden wird. Rein vorbeugend, ohne sichtbare Wirkung.

---

## 7. Preis-Chart und Vergleichs-Chart waren ohne Wallet-Adresse nicht erreichbar

**Problem:** Die Preiszeile (`.tp-price-top` — die Karte mit der RUNE-Kachel links und der
Vergleichs-Coin-Kachel rechts) war an `wallets.length > 0` geknüpft. Ohne eingetragene Adresse
wurde sie gar nicht gerendert.

Diese Zeile ist aber der **einzige Einstieg** in beide Charts:

- linke Kachel → `setShowRunePriceChart(true)` → RUNE-Preis-Chart
- rechte Kachel → `setShowCompareChart(true)` → Vergleichs-Chart

Ohne sie waren beide Fenster für Erstbesucher schlicht nicht erreichbar — es gab keinen zweiten
Weg dorthin. Die zweite Fundstelle von `priceRowBox` (in der Seitenspalte, `.tp-price-sidebar`)
zählt nicht: Die ist per CSS dauerhaft auf `display: none` gesetzt.

Bemerkenswert dabei: die **Daten waren längst da**. `fetchPortfolio()` läuft seit einer früheren
Änderung bewusst auch ohne Adresse und holt Kurs und Kurshistorie (siehe den Kommentar am
Start-`useEffect`, „Beim Start immer laden, unabhängig davon, ob schon eine Wallet gespeichert
ist"). Auch die Chart-Modals selbst hängen an `hasData`, nicht an `wallets.length` — und
`hasData` wird allein durch den erfolgreichen Preis-Abruf true. Es fehlte also nur der Knopf,
nicht der Inhalt dahinter.

**Fix:** `wallets.length > 0 &&` vor `priceRowBox` entfernt (eine Stelle, rund Zeile 34286).

Die eigene Sichtbarkeitsprüfung von `priceRowBox` bleibt unangetastet: Die Karte rendert
weiterhin nur, wenn tatsächlich ein Preis vorliegt (`activePrice != null || activeAltPrice !=
null`) — es entsteht also kein leeres Gerüst während des ersten Ladens, und der CLS-Schutz
bleibt wirksam.

**Bewusst unverändert:**

- Der Hinweis „Adresse eingeben" bleibt stehen. Er steht ohnehin *über* dem Inhalt als Hinweis,
  nicht an dessen Stelle als Sperre.
- Portfolio-Wert, Bond Rewards und alles andere Wallet-Gebundene bleiben an die Adresse
  geknüpft. Geändert hat sich nur das, was reine Marktdaten sind.
- Mit eingetragener Adresse ändert sich nichts: Die Bedingung wurde nur schwächer, der Fall
  `wallets.length > 0` rendert unverändert.

**Betroffene Dateien:** `app.js`

---

## 8. rune.watch Pro: automatische Chart-Analyse (neues Paket, aktuell kostenlos)

**Was es ist:** Ein Analyse-Werkzeug direkt im RUNE-Preis-Chart und im Vergleichs-Chart
(Hochkant, Querformat-Vollbild, linear UND Log-Skala). Es analysiert den gerade **sichtbaren
Zeitraum** — jeder Zoom, jedes Verschieben, jeder Intervall- oder Coin-Wechsel und jede neue
Live-Kerze lösen eine Neuberechnung aus; es gibt keinen „Aktualisieren"-Knopf, weil keiner
nötig ist.

**Was es zeichnet und erklärt** (jedes Element trägt ein kleines ⓘ, ein Tipp darauf öffnet eine
zwei- bis dreisätzige Laien-Erklärung samt Kontext wie „4 Berührungen · zuletzt 12.09."):

- **Elliott-Wellen:** regelbasierte Zählung über die groben Wendepunkte. Die drei harten Regeln
  sind Pflicht (Welle 2 nie unter Start von 1, Welle 3 nie die kürzeste, Welle 4 nie in Welle 1),
  Fibonacci-Richtwerte (2 ≈ 0,5–0,618 · 3 ≈ 1,618×1 · 4 ≈ 0,382 · 5 ≈ 1) erhöhen nur die
  Konfidenz. Erkennt vollständige Impulse (0–5), laufende („Welle 3 läuft", „Welle 5 läuft"),
  angehängte A-B-C-Korrekturen und reine Zickzack-Korrekturen. Liefert Kursziele je Phase und —
  falls vorhanden — eine alternative Zählung. Ein unbestätigter letzter Punkt wird gestrichelt
  gezeichnet und mit * markiert.
- **Chartmuster (14):** Doppel-Top/-Boden, Kopf-Schulter und inverse Kopf-Schulter, auf-/
  absteigendes und symmetrisches Dreieck, steigender/fallender Keil, Aufwärts-/Abwärtskanal,
  Seitwärtsrange, bullische/bärische Flagge. Mit Status (in Bildung / bestätigt / Ausbruch), Richtung, Konfidenz, Kursziel
  und eingezeichneten Nackenlinien bzw. Begrenzungslinien. Umkehrmuster verlangen einen echten
  Vortrend und einen spürbaren Rückzug vom letzten Extrem — sonst meldet der Algorithmus in
  jeder Seitwärtsphase laufend „Doppel-Tops".
- **Support / Widerstand:** geclusterte Wendepunkte (plus höchstes Hoch / tiefstes Tief des
  Kontexts) als Zonen mit Berührungszahl und Stärke; bis zu drei unter, drei über dem Kurs, plus
  die Zone, in der der Kurs gerade steckt.
- **Fibonacci:** automatisch am letzten signifikanten Swing — Rücksetzer-Level, solange der Kurs
  im Swing liegt, Erweiterungen (127,2 % … 261,8 %), sobald er darüber hinaus ist. Das Level, an
  dem der Kurs gerade klebt, ist hervorgehoben. Im Log-Modus wird im Log-Preisraum interpoliert,
  genau wie beim manuellen Fibonacci-Werkzeug.
- **Indikator-Auswertung:** SMA 200, EMA 20, Bollinger (inkl. Squeeze), VWAP (verankert am
  Start des sichtbaren Zeitraums), RSI 14 (inkl. Divergenz an den letzten Pivots), MACD
  (Kreuz / Stärke), Stochastic (Kreuz in den Extremzonen), Volumen (Spitze / dünn / steigend).
  Aktive Indikatoren stehen oben und zählen in die Gesamt-Einschätzung; inaktive sind gedimmt
  und lassen sich direkt aus dem Panel einschalten.
- **Gesamtbild:** Bullisch / Bärisch / Neutral mit Prozentbalken, ein Kernsatz aus Trend,
  Elliott-Phase, wichtigstem Muster und Indikator-Bilanz.

**Wo es sitzt:**

- Werkzeugleiste des Charts: Knopf **„Analyse · PRO"**. Pulsiert leicht, solange die Analyse aus
  ist, leuchtet ruhig, wenn sie an ist. Standard beim ersten Öffnen: **an** (soll auffallen);
  der Zustand wird gespeichert (`tp_pro_analysis_on`).
- Unter dem Chart: kompakte Zeile (Einschätzung, Trend, Elliott-Phase, Muster, Ebenen-Schalter
  Elliott / Muster / S/R / Fibonacci, „Details"). Aufgeklappt: alle Abschnitte mit ⓘ-Erklärungen,
  Kurszielen und Indikator-Ablesungen. Im Handy-Vollbild ist der Detailbereich auf 48 % der Höhe
  begrenzt und scrollt — der Chart behält mindestens sein Minimum.
- Startseite: **PRO-Badge** auf beiden Preis-Kacheln (am PC „Chart-Analyse · gratis · PRO", am
  Handy nur „✦ PRO"), mit Tooltip. Das Badge nutzt den Verlauf des Haupt-Buttons, damit es als
  Produkt-Hinweis lesbar ist.

**Abgleich mit Open-Source-Projekten (auf Wunsch):** Die Logik wurde gegen vier GitHub-Projekte
gehalten — `btcorgtfo/ElliottWaveAnalyzer` (Regelwerk `WaveRules.py`),
`hobbit7771/elliott-wave-analyzer` (`rules_impulse.py`, `rules_diagonal.py`,
`rules_correction.py`), `ESJavadex/elliot-waves-auto` (`improved_elliott.py`, Scoring) und
`BennyThadikaran/stock-pattern` (Muster-Kriterien). Übernommen wurde, was fachlich belastbar ist:

- Plausibilitätsregeln für Impulse: Welle 2 ≥ 20 % von 1, Welle 3 ≥ ⅓ von 1 und länger als 2,
  Welle 4 ≥ ⅓ von 2, Dauer von 2 ≤ 9× und von 3 ≤ 7× die Dauer von 1 (WaveRules.py).
- **Diagonale (Keil)** als bewiesene Ausnahme der Überlappungsregel: Welle 4 darf in Welle 1
  ragen, aber nur wenn 3 < 1 und 5 < 3 (rules_diagonal.py: „eine Diagonale muss bewiesen, nicht
  angenommen werden"). Wird als eigene Art angezeigt und erklärt.
- Alternation: Welle 2 und 4 sollten sich in der Tiefe unterscheiden (elliot-waves-auto).
- Volumen-Richtlinie: Welle 3 mit dem meisten Volumen, Welle 5 mit weniger als 3.
- Korrekturen: **Zickzack** (B ≤ 0,786 von A) vs. **Flat** (B ≥ 0,9, bis 1,3 erweitert),
  C zwischen 0,6× und 2,61× A, B-Dauer ≤ 10× A (rules_correction.py, WaveRules.py); zweites
  Prüffenster, damit eine gerade abgeschlossene Korrektur nicht vom laufenden Gegenzug verdeckt
  wird.
- Doppel-Top/-Boden: Volumen am zweiten Extrem niedriger als am ersten erhöht die Konfidenz
  (stock-pattern `is_double_top`).

Bewusst **nicht** übernommen: die Rolling-Window-Masken aus `TradingPatternScanner` (zu grob,
liefern Treffer auf fast jeder Kerze) und die vollständige rekursive Subwellen-Zählung — die
ist laut hobbit7771 selbst „ein Forschungsproblem, an dem auch Profis scheitern".

**Nachtrag — „Muster verschwinden, wenn ich den Chart etwas verschiebe":** Das war ein
Konstruktionsfehler, keine Laune der Daten. Drei Ursachen, alle behoben:

1. Der ZigZag lief ab dem **linken Bildrand**. Jedes Verschieben änderte den Startpunkt und
   damit die Wendepunkte. Jetzt läuft er immer ab der ersten geladenen Kerze bis zur letzten
   sichtbaren (gecacht je Datenreihe, Verschieben kostet nichts mehr); die Wendepunkte hängen
   nur noch von den Daten ab — wie die Fraktal-Pivots in `stock-pattern`, nur volatilitäts-
   statt fix-basiert. Bis zur letzten *sichtbaren* Kerze, damit beim Blick in die Vergangenheit
   nichts aus der Zukunft durchsickert.
2. Die ZigZag-Schwelle wurde nach der **Anzahl der Pivots im Fenster** gewählt — ein anderes
   Fenster kippte auf eine andere Stufe. Jetzt kommt sie aus der Volatilität (k × ATR) und wird
   nur grober, wenn in einer auf Zweierpotenzen gerundeten Referenzspanne (64, 128, 256 …
   Kerzen) zu viele Pivots liegen. Gleiche Zoomstufe = gleiche Schwelle.
3. Ein Muster fiel weg, sobald sein **erster** Pivot 15 % über den linken Rand hinaus war.
   Jetzt bleibt es, solange sein **letzter** Pivot im Bild ist; der Anfang darf links hinausragen.
   Der Kontext für Muster und Elliott (2× bzw. 3× Fensterbreite, in Zweierpotenz-Schritten)
   wandert ebenfalls nicht mehr mit jeder Kerze mit.

Dazu rastet das Analysefenster im Chart in Sechzehntel-Schritten der sichtbaren Kerzen ein,
und solange die neueste Kerze (fast) im Bild ist, gilt sie als rechte Kante („live"). Ergebnis
im Test: 0 von 27 Fenstern ändern Muster oder Zählung, wenn der linke Rand um 1–8 Kerzen
verschoben wird (vorher: fast jedes).

**Nachtrag 2 — Wochen-Chart: „Warum keine Muster und Elliott?"** Zwei Befunde aus dem
Screenshot:

- Die Ebenen „Muster" und „Fibonacci" waren **ausgeschaltet** (Chips grau), während die Zeile
  trotzdem „3 Muster" meldete. Ausgeschaltete Ebenen sind jetzt unmissverständlich: Chip
  durchgestrichen mit ○ statt ●, Tooltip „ausgeblendet – antippen zum Einzeichnen", und die
  Meldung in der Zeile trägt „(ausgeblendet)".
- Die Elliott-Zählung war **fachlich falsch**: Sie zeigte den Impuls von 2020/21 plus „A" und
  behauptete „Welle B läuft" mit Ziel $14 — fünf Jahre Kursverlauf danach wurden ignoriert.
  Ursache: Der Kandidaten-Score bevorzugte Impulse mit schönen Fibonacci-Verhältnissen,
  egal wie alt. Jetzt zählt ein kompletter Impuls nur, wenn er samt der ihm folgenden
  A-B-C-Korrektur bis an den letzten oder vorletzten Wendepunkt heranreicht — eine Zählung
  muss die *aktuelle* Position beschreiben. Ältere Strukturen fallen weg; in diesem Fall
  greift dann die Korrektur seit 2024 (A-B-C, Welle C läuft).

**Nachtrag 3 — Monats-Chart: „Muster an, trotzdem nur ein Muster":** Das war eine Grenze der
Suche, keine Einstellung. Drei Ursachen:

1. Dreiecke, Keile und Kanäle wurden nur am **rechten Ende** der Wendepunkte gesucht. Jetzt an
   jedem möglichen Ende über die gesamte sichtbare Historie (je Ende das beste Fenster aus
   4–7 Pivots); Überschneidungen löst die Konfliktregel auf, 4-Punkt-Dreiecke stehen dabei
   hinter Umkehrmustern zurück.
2. Die ZigZag-Schwelle hing an der ATR — bei Monatskerzen mit 30–60 % Spanne verschluckte
   das fast jeden Wendepunkt. Die Schwelle ist jetzt gedeckelt (mittel 22 %, grob 35 %,
   fein 15 %), die Gleichheits-Toleranz für Doppel-Tops hat eine Untergrenze von 2,5 %.
3. Die Obergrenze lag fest bei drei Mustern. Jetzt wächst sie mit den sichtbaren
   Wendepunkten (3 bis 6).

Dazu bewerten alte Muster ihren **damaligen Ausgang** am nächsten Wendepunkt hinter dem
Muster — bestätigt, Ausbruch oder neu „gescheitert (kein Durchbruch)" — statt am heutigen Kurs
(ein Doppel-Top von 2021 am Kurs von 2026 zu messen ergibt keinen Sinn). Gescheiterte Muster
bekommen kein Kursziel und zählen nicht in die Gesamt-Einschätzung; alte Muster ziehen ihre
Linien nur so weit wie ihre eigene Breite, nicht durch den ganzen Chart. Beschriftungen, die
am oberen Rand zusammenfielen, rücken sich jetzt gegenseitig aus dem Weg.

**Nachtrag 4 — aus dem Video (Monats-Chart):**

- **Ziele erklären sich jetzt selbst.** Jedes Kursziel trägt seine Herleitung — im ⓘ-Popover
  als eigener Block „So kommt das Ziel zustande" und im Detail-Panel unter jedem Ziel. Elliott:
  „Ende Welle 2 ($0,50) + 1,618 × Welle 1 ($0,30 / 30,0 %) = $0,99"; Muster: „Nackenlinie
  $0,55 − Musterhöhe $0,28 (51 %) = $0,27" bzw. „Ausbruchskante … ± Musterhöhe …". Die
  Engine liefert dafür Ausgangspunkt, Faktor und Referenzwelle mit Länge (absolut und in %),
  das UI formt den Satz — in allen 10 Sprachen.
- **Weniger „keine Zählung":** Wo die strengen Impuls-/Korrekturregeln nichts übrig lassen,
  gibt es jetzt eine vorläufige 1-2-Zählung aus den letzten drei Wendepunkten („Welle 2 läuft
  (vorläufig)" bzw. „Welle 3 läuft"), mit niedriger Konfidenz und Zielen für Welle 2
  (0,618-Rücksetzer) und Welle 3 (1,618×W1). Elliott-Quote auf Zufallsdaten: 92 % statt 55 %.
- Dass sich auf dem Monats-Chart beim Verschieben nichts ändert, ist nach Nachtrag 1 richtig —
  dort ist immer die gesamte Historie im Bild, also dieselben Daten. Dass dabei nur ein
  Muster gefunden wurde, war Nachtrag 3 (Suche über die ganze Historie, Schwellen-Deckel).

**Nachtrag 5 — „alles noch zu ungenau": Elliott v2 und Muster v2, direkt aus den Repos portiert.**

*Elliott-Wellen v2 (nach `btcorgtfo/ElliottWaveAnalyzer`, MonoWave + WaveOptions):* Die alte
Zählung nahm nur direkt aufeinanderfolgende Wendepunkte — ein Impuls, dessen Welle 3 selbst
zwei kleine Rücksetzer enthält, wurde nie gefunden. Jetzt darf jede Welle kleinere
Gegenbewegungen **überspringen** („skip"): ihr Ende ist jedes spätere neue Extrem in
Wellenrichtung, solange dazwischen der Wellenanfang nicht durchbrochen wird (exakt die
`find_end()`-Logik der Referenz, mit Start- und Limit-Preis für Regel 1/3). Aus allen
Kombinationen (bis zu 4 Kandidaten je Welle, ebenso für A-B-C) bleiben nur die, die alle harten
Regeln erfüllen; die beste nach Fibonacci-Richtlinien, Alternation, Volumen, Aktualität und
Strukturgröße gewinnt. Welle 3 als längste wird stärker gewichtet, eine Welle 5, die länger als
3 ist, abgestuft. Läuft auf den mittleren Pivots mit Kontext, Rückfall auf die groben.
Ergebnis: Elliott-Zählung in 100 % der Testfenster (vorher 55 %), Ø-Konfidenz 69 statt 51;
der Test „Welle 3 mit Unterwellen" findet den Impuls jetzt.

*Muster v2 (nach `BennyThadikaran/stock-pattern`):*

- **Harmonische Muster neu:** Gartley, Bat, Butterfly, Crab, AB=CD — mit den Ratio-Fenstern
  aus `find_bullish_gartley/bat/butterfly/crab/abcd` (B-, C-, D-Retracement von XA bzw. AB).
  D ist die „potenzielle Umkehrzone": existiert dort schon ein Pivot, gilt das Muster als
  vollendet, sonst ist D das Kursziel. Herleitung z. B. „D = A ($1,50) − 0,786 × XA ($0,50 / 33 %)".
  Punkte werden mit X/A/B/C/D beschriftet.
- **Flaggen neu:** bullische/bärische Flagge (steile Stange, enge Konsolidierung mit < 50 %
  Rückgabe, Ausbruch über die Konsolidierungskante), auf den feinen Pivots, weil die
  Konsolidierung auf der mittleren Auflösung nicht sichtbar wäre. Ziel = Kante ± Stangenlänge.
- **Intakt-Prüfung** (aus `find_triangles`): zwischen Anfang und letztem Pivot darf kein
  Schlusskurs die Begrenzungslinien eines Dreiecks/Kanals/Rechtecks verletzt haben — sonst ist
  es eine nachträglich gezogene Linie, kein gehandeltes Muster.
- **Doppel-Top/-Boden:** engere Gleichheit (eine ATR-Einheit statt 1,3), Bonus bei einer halben;
  die beiden Extreme dürfen jetzt auch 2 oder 4 Pivots auseinanderliegen (Zwischen-Hochs müssen
  unter beiden Tops bleiben, Nackenlinie = tiefstes Tief dazwischen) — das entspricht dem
  „höchstes Hoch, dann höchstes Hoch danach" der Referenz.
- Konflikte: vollendete harmonische Muster gewinnen gegen Dreiecke, 4-Punkt-Dreiecke stehen
  hinter Umkehrmustern zurück, Muster mit unbestätigtem Endpunkt werden abgestuft.

Rechenzeit bleibt klein: 30 Analysen über 400 Kerzen ≈ 230 ms, eine über 3.000 Kerzen ≈ 10 ms.

**Nachtrag 6 — „Fibonacci öfter, Muster übersichtlicher, Wahrscheinlichkeiten, Elliott genauer":**

- **Harmonische Muster entfernt** (auf Wunsch). Damit 14 Mustertypen.
- **Fibonacci in drei Ebenen**, jetzt praktisch immer sichtbar:
  1. *Gesamtbewegung* — höchstes Hoch ↔ tiefstes Tief des sichtbaren Zeitraums, zeitlich
     geordnet. Ist immer da, auch über Jahre auf dem Monats-Chart.
  2. *Letzter Swing* — der aktuelle Rücksetzer/Ausbruch (grobe Pivots), nur wenn nicht identisch
     mit 1.
  3. *Elliott-gekoppelt* — die Level, die zur **laufenden Welle** gehören: Welle 2 → 38,2/50/
     61,8/78,6 % von Welle 1; Welle 3 → 1,0/1,618/2,0/2,618 × Welle 1 ab Ende 2; Welle 4 →
     23,6/38,2/50 % von 3; Welle 5 → 0,618/1/1,618 × Welle 1 und 0,618 × (1–3); Korrektur →
     Rücksetzer des Impulses; C → 0,618/1/1,272/1,618 × A. Beschriftet als „Welle 3 × 1,618".
     Das ist die Verzahnung von Elliott und Fibonacci.
  Dazu **Konfluenz**: fallen Level verschiedener Ebenen (oder eine S/R-Zone) auf denselben
  Preis (± 0,7 Toleranz), wird der Preis mit ★ markiert — dort ist die Reaktion am
  wahrscheinlichsten. Bis zu vier Konfluenzen, nach Stärke sortiert, mit Herkunftsliste.
- **Muster-Beschriftungen nur auf Tipp:** Die Linien und Punkte eines Musters sind selbst die
  Trefferfläche (unsichtbar 14 px breit). Ein Tipp öffnet Name, Status, Konfidenz,
  Ausbruchs-Statistik und Ziel-Herleitung; im Chart erscheint dann kurz die Beschriftung.
  Ältere Muster werden mit 70 % Deckkraft gezeichnet. Die Kompaktzeile weist mit „Muster
  antippen für Bezeichnung" darauf hin.
- **Ausbruchs-Wahrscheinlichkeiten je Muster** nach Bulkowski (Encyclopedia of Chart Patterns,
  gerundet, als Literatur-Richtwert gekennzeichnet): z. B. aufsteigendes Dreieck 63 % oben /
  37 % unten, Ziel erreicht ~75 %; symmetrisches Dreieck 54/46; steigender Keil 31/69;
  fallender Keil 68/32; Rechteck 61/39; Flaggen 66/34 bzw. 34/66; Umkehrmuster als Trefferquote
  nach Bestätigung (Doppel-Top 89 % unten, Kopf-Schulter 96 %). Im Popover und im Panel mit
  Balken.
- **Muster nach Lehrbuch nachgeschärft:** Dreiecke brauchen mindestens 5 Berührungen (3 auf
  einer, 2 auf der anderen Seite) und scheitern, wenn der Kurs den Apex ohne Ausbruch erreicht
  (Apex-Regel); Dreiecke/Keile werden zusätzlich auf den feinen Pivots gesucht (≥ 6
  Berührungen, abgestuft), Kanäle/Rechtecke nur auf den mittleren. Kopf-Schulter: Nackenlinie
  höchstens leicht geneigt (≤ ⅓ der Kopfhöhe), Schultern zeitlich symmetrisch (≤ 2,5:1),
  Volumen-Bonus bei fallendem Volumen. Doppel-Top: Mindestabstand 4 Kerzen. Gescheiterte Muster
  werden in der Konfliktregel deutlich abgestuft.
- **Elliott noch genauer:** (a) **Frühere Strukturen** — vor der aktuellen Zählung werden bis
  zu drei weitere Impulse/Korrekturen rückwärts gezählt, jede endet, wo die nächste beginnt;
  gedimmt mit Labels in Klammern gezeichnet, im Panel als Kette „Impuls ↑ (0-1-2-3-4-5) →
  Korrektur ↓ (0-A-B-C) → …". Ein langer Zeitraum bekommt so eine durchgehende Wellenkarte.
  (b) **Unterwellen** — ab dem letzten bestätigten Punkt der Zählung wird die laufende Welle
  auf den feinen Pivots noch einmal gezählt (i-ii-iii-iv-v bzw. a-b-c), klein und kursiv
  gezeichnet: man sieht, wie weit z. B. Welle 3 intern schon ist.

**Nachtrag 7 — Feinschliff aus den Screenshots (Wochen-Chart, Startseite):**

- **Kleiner Swing-Fib nur mit eigener Aussage:** Der „letzter Swing"-Satz erscheint nur noch,
  wenn der Swing mindestens die halbe Log-Spanne der Gesamtbewegung hat. Ein Teil-Swing am
  Rand (wie im Screenshot: 0,295 → 0,638 innerhalb 0,295 → 2,189) legte seine Level genau
  über die der Gesamtbewegung — jetzt bleibt dort nur die Gesamtbewegung.
- **Startseiten-Badge kurz:** nur noch „✦ PRO" (die lange Beschriftung hat die Kachel-Zeile am
  PC gesprengt). Erklärung im Tooltip und im Chart selbst.
- **Ziele nach Trefferquote:** Bulkowski empfiehlt, die Musterhöhe mit dem Anteil zu
  multiplizieren, der das volle Ziel erreicht. Das *wahrscheinliche Ziel* (z. B. Doppel-Top:
  Nackenlinie − Höhe × 73 %) ist jetzt das gezeichnete und primäre Ziel, das *volle Ziel* steht
  daneben (kleiner Ring im Chart, Text im Panel). Herleitung entsprechend: „Nackenlinie $1,34
  − Musterhöhe $0,17 (12,5 %) × 73 % Trefferquote = $1,22 (voll: $1,18)". Elliott zeichnet nur
  noch das erste (wahrscheinlichste) Ziel im Chart, die weiteren stehen im Panel.
- **Muster besser gezeichnet:** Fläche zwischen Ober- und Unterlinie (Dreiecke, Keile, Kanäle,
  Rechtecke, Flaggen), Verbindungslinie der beiden Extreme bei Doppel-Top/-Boden bzw. der
  Schultern bei Kopf-Schulter, Ausbruchsmarke (Dreieck) an der ersten Kerze, deren Schluss die
  Kante durchbricht. Alle Beschriftungen im Chart weichen sich jetzt gegenseitig aus.
- **Analyse-Leiste einklappbar:** Knopf ▴ rechts in der Leiste blendet sie auf einen schmalen
  Chip („✦ Chart-Analyse · Bullisch 62 % ▾") zusammen — der Chart wird auf dem Handy
  entsprechend größer, die Zeichnungen bleiben an. Zustand gespeichert (`tp_pro_panel_hidden`).

**Nachtrag 8 — Ausblenden-Knopf war selbst das Problem:** Im letzten Paket sass der
Ausblenden-Knopf in derselben umbrechenden Zeile wie die Ebenen-Chips. Auf dem Handy (siehe
Screenshot) ist er dadurch in eine **eigene, isolierte Zeile** gerutscht — er hat selbst Platz
gekostet, statt welchen zu sparen, und war zudem schwer zu finden.

**Fix:** Eine neue Kopfzeile („Chart-Analyse PRO … ▾") ist jetzt fest `nowrap` — Titel links,
Ausblenden-Pfeil rechts, in derselben Position wie das X oben am Chart, unabhängig vom Inhalt
darunter. Das spart eine ganze Zeile und macht den Knopf sofort auffindbar. Ein Tipp klappt die
gesamte Leiste auf einen schmalen Chip zusammen; die Zeichnungen im Chart bleiben an.

**Nachtrag 9 — „viele Fibonaccis überlappen sich":** Der letzte Stand zeichnete alle drei
Fibonacci-Sätze (Gesamtbewegung, Swing, Elliott) plus bis zu vier Konfluenzen **gleichzeitig**.
Bei ~15–40 Kerzen ergab das Dutzende Linien und Label übereinander (siehe Screenshot) — unlesbar.

**Fix:**
- **Nur noch EIN Satz gleichzeitig.** Standard ist „beste": die Engine wählt automatisch den
  relevantesten — die Elliott-gekoppelten Level, wenn eine Zählung läuft und die Ebene an ist;
  sonst der letzte Swing; sonst die Gesamtbewegung. Im Panel klickt man mit dem Chip
  „fib: beste / gesamt / swing / Elliott" gezielt durch, sieht aber immer nur einen.
- **Auf schmalen Screens (< 560 px) nur die wichtigen Verhältnisse** (0 / 38,2 / 50 / 61,8 /
  100 / 161,8 %) statt aller sieben — die Linien stehen dadurch nicht mehr zu dicht.
- **Konfluenz reduziert:** breit höchstens zwei, auf dem Handy höchstens eine (die stärkste),
  dort nur „★ Preis" statt der langen Beschriftung.
- Alle Label weichen sich weiterhin gegenseitig aus.

**Nachtrag 10 — „immer noch Überlappungen, keine Änderungen":** Der Screenshot zeigt den
**vorherigen Build**: zwei Fib-Sätze (0,0 % $0,631 zweimal), vier Konfluenzen, im Panel der alte
Text „2 patterns (hidden – tap to show)" und **kein** „fib: beste"-Chip. Nachtrag 9 war also gar
nicht geladen — der Browser (iPhone/Safari) hatte die alte `app.js` im Cache, weil sie ohne
Versionsparameter eingebunden war.

**Fix, damit das nie wieder passiert:**
- `index.html` bindet `app.js?v=<Build-Stempel>` ein (React-Dateien mit `?v=18.3.1`). Jedes
  neue Paket bekommt automatisch einen neuen Stempel → der Browser lädt zwingend neu.
- Der Build-Stempel steht sichtbar in der Fußzeile der Analyse-Details („build 20260915-2051")
  und im Tooltip der Kopfzeile. Weicht er vom README ab, ist es der Cache.

(Aktueller Build: siehe Nachtrag 11.)

**Nachtrag 11 — Muster raus, Elliott als Hauptsache mit erwartetem Verlauf:**

- **Chartmuster komplett entfernt** (auf Wunsch): keine Erkennung, kein Overlay, kein
  Panel-Abschnitt, keine Ebene, keine Übersetzungen. Die Analyse besteht jetzt aus Elliott,
  Fibonacci (an Elliott gekoppelt), Support/Widerstand, Indikatoren und Gesamtbild.
- **Erwarteter Verlauf:** Aus der laufenden Phase berechnet die Engine die nächsten 1–3
  Wellenenden — Preis aus den Fibonacci-Richtwerten (Welle 3 = 1,618 × W1, Welle 4 = 0,382 von 3,
  Welle 5 = W1, Korrektur A = 0,382 des Impulses, C = A …), Zeit aus der Dauer der analogen
  früheren Welle. Im Chart als **gestrichelter Pfad** ab der aktuellen Kerze mit nummerierten
  Punkten und Preisen; im Panel als Kette „→ 3 $1,70 → 4 $1,50 → 5 $1,83" mit ⓘ-Erklärung
  (Szenario, keine Prognose). Damit der Pfad Platz hat, lässt der Chart bei aktiver Analyse
  rechts ~28 % der Breite frei (vorher 3 %). Liegt ein Ziel außerhalb des Preisbereichs, steht
  „↕" am Label.
- **Übersichtlicher:** nur noch eine frühere Struktur (gedimmt) statt drei; Unterwellen sind
  eine eigene, standardmäßig ausgeschaltete Ebene („Unterwellen"); Punkt 0 nur als Marke ohne
  Kreis; im Chart nur noch der Pfad, keine zusätzlichen Ziel-Linien.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 12 — „Das Fenster öffnet unten, man muss scrollen auf dem Handy":** Die
ⓘ-Erklärung war am Punkt in der Kurve verankert (Kerzen-Index/Preis in Pixel umgerechnet). Bei
einer tief im Chart sitzenden Markierung — im Screenshot eine Konfluenz nahe der Chart-
Unterkante — landete das Popover entsprechend weit unten auf der Seite. Der Chart ist auf dem
Handy mit Volumen und Indikatoren oft länger als ein Bildschirm; das Popover war dadurch
außerhalb des sichtbaren Bereichs und man musste erst dorthin scrollen.

**Fix:** Auf schmalen Screens (< 560 px) hängt das Popover jetzt **fest am unteren Rand des
Sichtfensters** (`position: fixed`), unabhängig davon, wo die Markierung im Chart sitzt — es
ist immer sofort da, mit eigenem Scrollbereich bis 46 % der Bildschirmhöhe, falls der Text
länger ist. Am PC bleibt die bisherige, am Punkt verankerte Position, weil dort der ganze Chart
ohnehin ohne Scrollen sichtbar ist.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 13 — Popover musste trotz `position: fixed` immer noch weggescrollt werden:**
Nachtrag 12 hatte das Popover auf `position: fixed` gestellt, es blieb dabei aber ein normales
Kind tief im Chart-Kartenbaum (die Karte selbst hat `overflow: auto` und wird bei
aufgeklappten Details länger als der Bildschirm). `position: fixed` positioniert eigentlich
relativ zum echten Bildschirm — es sei denn, irgendein Vorfahre öffnet einen eigenen
„Containing Block" dafür (z. B. durch `transform`, `filter`, `backdrop-filter`, `contain` oder
`will-change`). Dann rutscht das „fixed" Element wieder mit dem Vorfahren mit, statt am
Bildschirm zu kleben — genau das ist hier offenbar irgendwo in der Kettenpassiert.

**Fix, der das Problem an der Wurzel umgeht statt die Ursache im CSS-Baum zu jagen:** Das
Popover hängt jetzt per **Portal** (`ReactDOM.createPortal`, wie an mehreren anderen Stellen der
App bereits verwendet) direkt an `document.body` — nicht mehr irgendwo im Chart-Kartenbaum. Als
direktes Kind von `<body>` ist es garantiert relativ zum echten Bildschirm positioniert, egal
was irgendein Vorfahre der Chart-Karte an CSS mitbringt.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 14 — Portal-Fix hat das Popover unsichtbar gemacht:** Der Portal aus Nachtrag 13
war richtig (Popover jetzt direktes Kind von `document.body`), aber genau dadurch entstand ein
neuer Fehler: Als Geschwister des Chart-Modals im DOM landete das Popover mit `z-index: 60` —
das Chart-Modal selbst deckt den ganzen Bildschirm mit `z-index: 1000` ab, das
Vollbild-Querformat-Overlay sogar mit `z-index: 999999`. Das Popover wurde also weiterhin
korrekt gerendert, aber vollständig **hinter** dem abgedunkelten Modal versteckt — für den
Nutzer nicht als „falsch positioniert", sondern als „gar nicht da".

**Fix:** `z-index: 1000050` — klar über beidem. Zusätzlich die Positionierung selbst robuster
gemacht: statt aus einem gespeicherten `offsetTop` (relativ zu einem möglicherweise scrollenden
Vorfahren, seit dem Portal ohnehin nicht mehr aussagekräftig) wird die Position jetzt live aus
`getBoundingClientRect()` des Charts berechnet — echte Bildschirm-Pixel, unabhängig davon, wo
das Popover im DOM hängt. Auch am PC jetzt `position: fixed` statt `absolute`, aus demselben
Grund.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 15 — Info-Fenster: kurz, im Zentrum des Charts, ohne Scrollen — und Cache endgültig:**

- **Zentriert im Chart:** Das Fenster liegt jetzt mittig über dem *sichtbaren* Teil des Charts
  (Chart-Rechteck geschnitten mit dem Bildschirm, live aus `getBoundingClientRect()`). Wer eine
  Markierung antippen konnte, hat den Chart im Bild — die Mitte davon ist also immer sichtbar,
  ohne Scrollen. Breite ≤ 320 px, Höhe ≤ 70 % des sichtbaren Charts (max. 260 px).
- **Kurz:** Titel, 2–3 Sätze, eine Kontextzeile. Die Ziel-Herleitung (der längste Teil) ist
  eingeklappt hinter dem Knopf „So kommt das Ziel zustande ▾".
- **Build-Stempel** klein unten rechts im Fenster — so lässt sich sofort erkennen, welche
  Version läuft.
- **Cache endgültig:** Ein Versionsparameter an `app.js` nützt nichts, wenn `index.html` selbst
  aus dem Cache kommt. Neue Datei **`_headers`** (Cloudflare Pages) setzt `Cache-Control:
  no-cache, no-store, must-revalidate` für `/` und `/index.html`; die Skripte (mit `?v=`) dürfen
  dauerhaft gecacht werden. **Bitte `_headers` mit hochladen** — sie gehört ins Wurzelverzeichnis
  neben `index.html`.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 16 — „Drei verschiedene Zählungen je nach Zoom — welche gilt?":** Das ist kein
Fehler, sondern der Kern von Elliott: Wellen bestehen aus Wellen (Grade). Beim Zoomen sieht man
einen anderen Grad, keine andere Meinung. Der größere Grad gibt die Richtung, der kleinere das
Timing. Was bisher fehlte, war, dass das Tool das **selbst sagt** und die Verzweigungen zeigt:

- **Übergeordneter Grad:** Dieselbe Zählung noch einmal auf dem 4-fachen Zeitraum (grobe
  Pivots). Im Panel als eigener Block („Übergeordneter Grad (4× Zeitraum): Impuls ↓ · Welle 4
  läuft · Konfidenz 71 %"), in der Kompaktzeile als Chip „Grad ↓ ✓/✗".
- **Konsistenz-Check:** Die sichtbare Zählung gilt als *passend*, wenn sie innerhalb der
  laufenden Bewegung des größeren Grads liegt und in dieselbe Richtung geht („passt zur größeren
  Zählung"); sonst „widerspricht der größeren Zählung" — dann ist eine der beiden falsch, und
  die ⓘ-Erklärung sagt, wie man damit umgeht (Richtung vom größeren Grad, Ungültigkeits-Niveaus
  beobachten).
- **Ungültigkeits-Niveau je Zählung:** Der Preis, an dem eine harte Regel bricht (Welle 2 unter
  Start von 1, Welle 4 in Welle 1, Welle 5 unter Ende von 4, Korrektur über Ende von 5, B über
  Start der Korrektur, C über Ende von B …). Im Chart als rote Punktlinie „✕ ungültig unter/über
  $X", im Panel mit der Regel im Klartext, auch für den übergeordneten Grad. Das ist die
  Verzweigung zwischen den Szenarien — solange das Niveau hält, gilt die Zählung.
- ⓘ-Erklärungen für Laien zu Graden, Konsistenz und Ungültigkeit in allen 10 Sprachen.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 17 — „Was passiert nach dem Ziel?" + Details als Akkordeon:**

*Szenarien nach dem Ziel.* Je Phase liefert die Engine 2–3 Verzweigungen mit **Auslöser**
(Schluss über/unter X, ggf. „nach/vor Erreichen von Ziel") und **Ziel**, dazu eine
Wahrscheinlichkeit. Beispiel Welle C läuft (Korrektur nach Abwärtsimpuls):
„↓ Korrektur endet, alter Trend setzt wieder ein 50 % — Auslöser: Schluss unter B nach
Erreichen von C", „↑ Läuft über das Ziel hinaus 30 % — Schluss über C", „✗ Ziel wird nicht
erreicht 20 % — Schluss unter B vor Erreichen von C". Die Basis-Prozente sind
Elliott-Faustregeln (C = A in ~60 % der Zickzacks, C = 1,618 A ~25 %, Abbruch ~15 %; Welle 3 →
Welle 4 folgt ~60 % usw.) und werden korrigiert um: übergeordneten Grad (passend ±8),
Indikator-Bilanz (bis ±10 in Richtung), Support/Widerstand nahe dem Ziel des
„darüber hinaus"-Szenarios (−5); dann auf 100 normiert. Im Chart als zwei dünne gestrichelte
**Äste ab dem Ziel** mit Prozent (grün ↑, rot ↓), im Panel als eigener Abschnitt mit Auslöser je
Szenario. Klar beschriftet als **Modell-Schätzung, keine Statistik** — ehrlicher geht es hier
nicht, denn es gibt keine belastbare Trefferstatistik für RUNE.

*Details als Akkordeon* (Video: „unübersichtlich"): sechs Abschnitte — Gesamtbild, Elliott, Nach
dem Ziel, Fibonacci, Support/Widerstand, Indikatoren — jeder eine Kopfzeile mit Kurzfassung
(„Elliott · Welle C läuft · 56 % · Grad ↓ ✓", „Nach dem Ziel · 50 % Korrektur endet … · 30 %
darüber hinaus", „Indikatoren · 2↑ 1↓ von 3"). Standard offen: Elliott und Szenarien, der Rest
klappt bei Bedarf auf. Die Inhalte selbst sind unverändert, nur nicht mehr alle gleichzeitig
sichtbar.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 18 — „Müssten es nicht in Summe 100 % sein?":** Ja. Im Chart standen nur die zwei
Äste *nach* dem Ziel (46 % + 37 %), das dritte Szenario „Ziel wird nicht erreicht" (17 %) nur
im Panel — irreführend. Jetzt wird es als dritter, grauer Ast gezeichnet: ab der **aktuellen
Kerze** zum Auslöser (Schluss unter B), mit „✗ 17 %" — so ergeben die drei Äste im Bild 100 %.
Ein Test prüft die Summe.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 19 — „Manchmal verwirrend mit den Prozenten, unübersichtlich":** Vier Ursachen,
alle im Overlay behoben:

- **Lose Prozentzahlen** an den Ast-Enden (47 % / 24 % / ✗ 29 %) sind weg. Stattdessen **eine
  Legende-Box** mit je einer Zeile pro Szenario — Farbpunkt = Farbe des Astes, Prozent,
  Kurzname („● 47 % ↓ Korrektur endet, alter Trend setzt wieder ein"). Die Box wählt die
  Ecke des Charts, in der sie am wenigsten kollidiert (Zählung, Projektion, S/R-Labels und
  vorhandene Beschriftungen werden gezählt). Bei Monatsdaten steht dort die 1–4-Jahres-Legende.
- **Kein doppeltes „C":** Die laufende Welle (gestrichelter Kreis am aktuellen Punkt) und ihr
  Ziel (Kreis der Projektion) trugen denselben Buchstaben. Jetzt markiert ein kleiner Punkt die
  laufende Welle, der Buchstabe steht nur noch am Ziel.
- **Preise der Projektionspunkte** stehen rechts neben dem Kreis (links, wenn der Rand nah ist)
  und weichen anderen Beschriftungen aus, statt sich über den Kreis zu legen.
- Das **ⓘ** der Zählung sitzt in der Legende-Box, nicht mehr mitten im Text am letzten Punkt.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 20 — Langfrist-Prognose und CoinGecko-Historie entfernt** (siehe Punkt 17/18).

Dieses Paket: **build 20260918-2041**.

**Nachtrag 21 — „Im Pro-Analyse-Tool ruckelt es so":** Beim Schieben und Zoomen änderte sich
das Analysefenster bei **jedem Frame**. Die Analyse selbst braucht nur 2–5 ms, aber das
anschließende Neu-Aufbauen des Overlays (hunderte SVG-Elemente) und des Panels mit 60 Bildern
pro Sekunde ist zu viel — der Chart stockte, und das Panel flackerte zwischen „Bullisch 82 %"
und „Etwas herauszoomen" (im Video gut zu sehen).

**Fix:** Während einer Geste bleibt das zuletzt berechnete Fenster stehen — die Zeichnung wandert
mit dem Chart mit, sie wird nur nicht neu gerechnet; **180 ms** nach der letzten Bewegung wird
einmal sauber nachgezogen. Dazu hält die Analyse ihr letztes brauchbares Ergebnis: Wird das
Fenster mitten in der Geste kurz zu klein, bleibt die alte Zeichnung stehen, statt wegzublinken.
Datenwechsel (anderes Intervall, anderer Coin) greifen weiterhin sofort.

Messung im Test (40 Frames Zoomen): **1 Neuberechnung statt 8** — und keine einzige mitten in
der Bewegung.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 22 — Legende kleiner und ohne abgeschnittenen Text:** Im Screenshot des Nutzers
(schmaler Android-Browser) stand „… alter Trend setzt wieder" — das „ein" fehlte —, und die Box
lag über der roten Ungültigkeits-Linie.

- **Kleiner:** Schrift 8,5 statt 9,5 px, Überschrift 7,5 px, engere Abstände, Breite auf 200 px
  begrenzt (schmale Screens) statt bis zur halben Chartbreite.
- **Kein Abschneiden:** Prozent und Beschreibung stehen in zwei Spalten; lange Namen brechen auf
  **zwei Zeilen** um. Passt selbst das nicht, wird die zweite Zeile mit „…" gekürzt — nie mehr
  mitten im Wort abgeschnitten. Die Boxbreite wird aus der tatsächlichen Zeilenlänge berechnet
  (mit Aufschlag für die fette Schrift).
- **Bessere Position:** Neben den vier Ecken stehen jetzt auch mittlere Höhen zur Wahl, und die
  Ungültigkeits-Linie zählt als belegt — die Box weicht ihr aus.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 23 — „Auf dem großen Zeitraum wird keine Elliott-Theorie angewendet, es wird zu
klein betrachtet":** Richtig. Die Engine zählte immer die *letzten* Wendepunkte einer festen
Feinheit — auf 300 Wochenkerzen ist das zwangsläufig die kleine Struktur der letzten Monate,
egal wie weit man herauszoomt. Die große A-B-C vom 2021-Hoch, die man mit bloßem Auge sieht,
kam nie als Hauptzählung vor.

**Grad-Wahl:** Bei weitem Fenster (≥ 120 Kerzen) wird von grob nach fein probiert
(Umkehrschwelle 60 % → 40 % → 28 % → 20 %). Die **gröbste** Stufe, deren Zählung mindestens
35 % des Fensters überspannt und wenigstens vier Punkte hat, wird die Hauptzählung. Auf dem
Gesamtchart ist das jetzt die Korrektur vom 2021-Hoch (0 = Mai 2021, A, B, C = Tief 2025,
„Korrektur fertig – neuer Impuls möglich"), im engen Fenster bleibt die feine Zählung der
letzten Monate. Die feine Zählung ist auf dem Gesamtchart weiterhin als Unterwellen (Ebene
„Unterwellen") verfügbar.

**Zwei Folgekorrekturen:** (1) Die Regel „Welle A über 3,3-fach ist keine Korrekturwelle"
(Nachtrag 18) hätte genau diese A-B-C verhindert — der Absturz 2021–22 *ist* die Welle A.
Jetzt bleibt der Kandidat bis 12-fach erlaubt, nur die für die Ziele verwendete A-Länge wird
auf 3,3-fach gedeckelt, damit „C = A" kein Fantasieziel ergibt. (2) Nach fertiger Korrektur war
das Ziel bisher „Niveau des Korrekturstarts" — auf dem Gesamtchart ein 30×-Versprechen. Jetzt:
38,2 % und 61,8 % der Korrektur zurückerobert, mit Herleitung.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 24 — Grad-Namen (Cycle, Primary, Intermediate …):** Elliott ordnet Wellen nach
Größe in Grade, jeder besteht aus Wellen des nächstkleineren: Grand Supercycle (Jahrhunderte) ·
Supercycle (Jahrzehnte) · Cycle (Jahre) · Primary (Monate bis ~2 Jahre) · Intermediate (Wochen
bis Monate) · Minor (Wochen) · Minute (Tage) · Minuette (Stunden) · Subminuette (Minuten). Das
Tool liest den Grad aus der **mittleren Dauer der Wellen** der jeweiligen Zählung ab (Schwellen:
2 Jahre / 4 Monate / 18 Tage / 4 Tage / 10 h / 1 h) und zeigt ihn in der Elliott-Kopfzeile
(„Welle C läuft · 46 % · Primary"), in der Detailzeile „Grad: Primary · Grad: Cycle" für die
übergeordnete Zählung, und im Block „Übergeordneter Grad". ⓘ erklärt die Reihe. Über Cycle ist
bei RUNE nichts zählbar — die Daten beginnen 2019; realistisch ist 2019–21 als Cycle-Welle I,
2021–25 als II (mit A-B-C auf Primary-Ebene), und ab 2025 möglicherweise III.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 25 — „Ich sehe immer noch keine andere Zählung" + Verbergen dauerhaft:**

*Grad-Wahl, zweiter Anlauf.* Nachtrag 23 griff auf echten Daten nicht zuverlässig: Die Engine
bevorzugt Strukturen „in Arbeit" und lieferte auf der groben Stufe deshalb oft nur eine
vorläufige 1-2 mit drei Punkten am rechten Rand — die fiel durch die Vier-Punkte-Hürde, und es
blieb die feine Zählung. Jetzt bekommt die Engine die Vorgaben direkt (`minPoints`,
`minSpan`) und wählt unter **allen** Kandidaten der groben Stufe den besten, der sie erfüllt.
Ergebnis auf dem Gesamt-Wochenchart je nach Datenlage: Impuls 1-2-3-4 abwärts vom 2021-Hoch
(1 = Tief 2022, 2 = Hoch 2024, 3 = Tief 2025, 4 läuft) **oder** A-B-C fertig — die Engine
entscheidet nach ihrer Konfidenz, die andere Lesart steht als Alternative im Panel. In drei
Varianten des Testdatensatzes (schwache, starke, keine Rally seit 2025) wird jedes Mal die
große Struktur ab 2021 gezählt.

*Ziele gedeckelt:* Auch die Impuls-Ziele rechnen im Log-Raum mit höchstens 3,3-facher
Referenzlänge — „Welle 5 = Welle 1" bei einer Welle 1 von −95 % ergab sonst ein Ziel bei drei
Cent.

*„Werte verbergen" bleibt erhalten* (gemeldet): Der Schalter lebte nur im Speicher der Seite.
Jetzt im localStorage (`tp_hide_value`), wie Sprache und Währung — nach Schließen und Öffnen der
App ist weiterhin verborgen.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 26 — „Immer noch klein gezählt" (dritter Anlauf) + Umschalter:**

*Was ich nicht konnte:* An die echten Binance-Wochendaten komme ich von hier aus nicht heran
(die API sperrt automatisierte Zugriffe). Ich kann also nur mit nachgebauten Kursverläufen
prüfen — dort griff die Grad-Wahl. Deshalb zwei Dinge statt weiterem Raten:

*Ursache gefunden und behoben:* Unter den Kandidaten der groben Stufe gewann der mit dem besten
Score — und das kann eine **spätere** Struktur sein, die die 35-%-Hürde zwar erfüllt, aber nur
die halbe Historie umfasst (Zählung ab dem Hoch 2024 statt ab dem Hoch 2021). Jetzt gewinnt
unter allen Kandidaten nahe am Bestwert (höchstens 12 Punkte darunter) der mit dem **frühesten
Start**. Auf dem nachgebauten RUNE-Wochenchart zählt „auto" damit: Impuls abwärts vom Hoch 2021,
1 = Tief 2022, 2 = Hoch 2024, 3 = Tief 2025, **Welle 4 läuft** — Grad Primary.

*Umschalter „Zählung: auto · groß · fein"* in der Kompaktzeile neben dem Fibonacci-Wähler. Damit
lässt sich die große Struktur erzwingen, auch wenn die Automatik auf deinen echten Daten daneben
liegt. „groß" ignoriert die 35-%-Hürde und geht notfalls bis zu feineren Stufen hinunter, „fein"
ist die frühere Zählung der letzten Wellen. Die Wahl wird gemerkt (`tp_pro_degree`).

Dieses Paket: **build 20260918-2041**.

**Nachtrag 27 — „Trotz groß keine Veränderung": Diagnose sichtbar gemacht.**

Ich kann die echten Binance-Daten von hier aus nicht laden, und auf allen nachgebauten
Verläufen greift die Grad-Wahl. Statt weiter zu raten, zeigt das Tool jetzt, **was es tut**:

- **„groß" nimmt jetzt wirklich die früheste gültige Struktur** — ohne Rücksicht auf den
  Punktwert. Vorher galt auch dort die Bedingung „nah am Bestwert" (höchstens 12 Punkte
  darunter); eine frühe Zählung mit unregelmäßigen Wellen fiel dadurch heraus, obwohl sie
  regelkonform war. Bei „auto" bleibt die Nähe-Bedingung, damit die Automatik keine schwache
  Zählung nur wegen ihres frühen Starts wählt.
- **Diagnose-Zeile** im Elliott-Abschnitt, sobald der Modus nicht „auto" ist:
  „Fenster 315 Kerzen, Modus coarse | 0.6: 5 Punkte ab 37 ✓" oder eben
  „0.6: nur 3 Wendepunkte | 0.4: 6 WP, keine gültige Zählung (≥4 Punkte) | Rückfall auf die
  feine Zählung". Damit ist von außen sichtbar, welche Stufe geprüft wurde und woran sie
  gescheitert ist.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 28 — Grad-Wahl greift (bestätigt) + Zoom-Zurücksetzen sichtbar:**

Die Diagnose aus Nachtrag 27 hat es gezeigt: „Fenster 316 Kerzen, Modus coarse · 0.6: 7 Punkte
ab 61 ✓" — die große Zählung steht (0 = $17,27 vom Hoch 2021, 1–5 abwärts bis $0,295, jetzt
Welle A, Grad **Primary**, 92 % Konfidenz). Die Grad-Wahl funktioniert also seit Nachtrag 27.

Was im selben Screenshot unbrauchbar aussah, war der Chart: Die Preisachse reichte von $0,005
bis $114, die Kerzen lagen auf einem schmalen Streifen. Das kommt nicht von der Zählung, sondern
von der **Achsen-Zoom-Geste** (Ziehen auf der Preis-Beschriftung staucht die Skala — Standard in
Chart-Apps, aber leicht versehentlich ausgelöst). Zurücksetzen konnte man das schon immer, nur
war der Knopf ein 16 × 16 großer Kreis in der Ecke.

**Jetzt:** Sobald die Preisachse verstellt ist (`yZoomDomain` oder `manualYZoomFactor`), wird
aus dem Symbol ein beschrifteter Knopf in Akzentfarbe („Zoom zurücksetzen"). Ist nur horizontal
gezoomt, bleibt er wie bisher unauffällig.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 29 — Die große Zählung war fachlich falsch. Behoben.**

Der Screenshot zeigte es: Welle 3 lief von $13,40 auf $0,59 — und enthielt dabei die komplette
Erholung auf ~$10 (Anfang 2024). Eine Antriebswelle, die intern fast vollständig zurückgelaufen
ist, gibt es nach Elliott nicht; an dieser Stelle hätte geteilt werden müssen. Die
Skip-Kombinatorik (aus `btcorgtfo/ElliottWaveAnalyzer` übernommen) übersprang den Punkt
stillschweigend — das Referenzprojekt prüft beim Überspringen nur, ob ein neues Extrem jenseits
des Startpunkts liegt, nicht wie weit die Welle zwischendurch zurücklief.

**Neue harte Regel:** Für jede Antriebswelle (1, 3, 5 bzw. A, C) wird das laufende Extrem
mitgeführt und an jeder Stelle gefragt, wie viel der bis dahin gelaufenen Strecke gerade
zurückerobert wurde. Über **61,8 %** (Fibonacci) wird der Kandidat verworfen. Gemessen wird erst
ab 20 % gelaufener Strecke — am Wellenanfang ist der Nenner naturgemäß winzig.

Ergebnis auf dem RUNE-Verlauf: **0 = $13,90 (Hoch Ende 2021) · 1 = $1,14 (Tief 2022) · 2 =
$10,02 (Hoch 2024) · 3 = $0,30 (Tief 2025) · 4 läuft** — die Erholung 2024 ist jetzt Welle 2
statt in Welle 3 verschluckt.

**Monats- und Tageschart:** Die Grad-Wahl verlangte 120 Kerzen im Fenster. Der Monatschart hat
über die ganze RUNE-Historie nur rund 70 — dort wurde sie deshalb **nie** aktiv. Schwelle auf 60
gesenkt; getestet mit 72 Monats-, 301 Wochen- und 1500 Tageskerzen: überall dieselbe große
Zählung, Grad Primary.

**Zurückgebaut:** Der beschriftete „Zoom zurücksetzen"-Knopf aus Nachtrag 28 ist wieder das
kleine Symbol wie zuvor.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 30 — Die Zählung weist sich selbst aus (Regelprüfung):**

Auf die Frage „ist die Zählung richtig?" sollte niemand raten müssen — auch ich nicht. Im
Elliott-Abschnitt steht jetzt eine **Regelprüfung**, die für die gerade angezeigte Zählung jede
harte Regel nachrechnet und mit den konkreten Zahlen belegt:

```
REGELPRÜFUNG
✓ Welle 2 hält den Start        W2 8.80 < 0 11.23
✓ Welle 3 nicht die kürzeste    W1 159 · W3 227 · W5 196
✓ Welle 4 ohne Überlappung      W4 2.13 < W1 2.28
· Rücksetzer                    W2 / W1 = 85 %
· Verlängerung                  W3 / W1 = 1.42×
· Rücksetzer                    W4 / W3 = 37 %
· Welle 5                       W5 / W1 = 1.23×
```

Haken = Regel nachgerechnet und erfüllt; ein ✕ wäre ein Regelbruch. Die Punkte-Zeilen sind
Fibonacci-Verhältnisse — Beschreibung, keine Regel. Bei Korrekturen entsprechend B gegen den
Start sowie B/A und C/A. Erkennt die Engine eine Diagonale (die einzige Ausnahme von der
Überlappungsregel), steht ◺ hinter der Welle-4-Zeile.

Gegenprobe zur Überlappungsregel: Ein Datensatz, bei dem Welle 4 knapp über dem Tief von Welle 1
liegt, wird von der Engine verworfen — sie zählt dann anders, statt eine ungültige Struktur zu
zeigen.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 31 — 5-3-5: die Unterteilung war das fehlende Merkmal.**

Gemeldet: „Wir haben doch hier 5-3-5, ist das nicht typisch für A-B-C? Wieso sehe ich das
nicht." Die Beobachtung ist fachlich richtig und deckt eine echte Lücke auf: Der **Zickzack ist
5-3-5** (A fünfteilig, B dreiteilig, C fünfteilig), der **Flat 3-3-5** — genau daran
unterscheidet man die beiden. Die Engine hat das bisher nur über die **Längenverhältnisse**
geraten (B-Rücklauf ≤ 78,6 % → Zickzack) und die Unterteilung nie nachgezählt.

**Jetzt:** Jede Teilwelle einer Korrektur wird auf feineren Wendepunkten nachgezählt (Feinheit
= ein Drittel der Stufe, auf der die Zählung selbst steht). Ergebnis steht im Elliott-Abschnitt
als eigene Zeile: „Unterteilung: 5-3-5 — Zickzack". Widerspricht das Muster der aus den Längen
abgeleiteten Einordnung, **gewinnt das Muster** — es ist das stärkere Merkmal. Ist eine
Teilwelle auf dieser Feinheit nicht aufgelöst (weniger als drei Segmente), wird gar nichts
behauptet, statt „1-1-1" hinzuschreiben.

Dieses Paket: **build 20260918-2041**.

**Nachtrag 32 — „auto → groß → fein verändert nichts": zwei Ursachen.**

*Nachleuchten (Fehler, behoben).* Seit Nachtrag 21 hält die Analyse ihr letztes brauchbares
Ergebnis, damit die Zeichnung beim Wischen nicht wegblinkt. Dieser Puffer galt auch beim
**Moduswechsel**: Fand der neue Modus keine Zählung, blieb schlicht die alte Zeichnung stehen —
es sah aus, als passiere gar nichts. Jetzt wird der Puffer beim Wechsel verworfen; findet ein
Modus nichts, steht dort „keine eindeutige Wellenzählung" statt einer stehengebliebenen alten.

*auto = groß ist oft korrekt.* Seit Nachtrag 29 wählt die Automatik auf weiten Fenstern
ohnehin die große Struktur. Dass „auto" und „groß" dasselbe zeigen, ist dann kein Fehler,
sondern die richtige Antwort. Damit man das sieht, nennt der Chip jetzt die tatsächlich
benutzte Stufe: „Zählung: groß · 60 %". Steht dort keine Prozentzahl, läuft die feine Zählung.

Dieses Paket: **build 20260918-2041**.

**Ehrlichkeit eingebaut:** Eine Elliott-Zählung ist nie „perfekt" — sie ist auch unter Profis
umstritten. Deshalb steht bei jeder Zählung eine Konfidenz, bei Muster und Zählung der Hinweis
„vorläufig", im Panel dauerhaft „Automatische Mustererkennung, keine Anlageberatung — sie kann
irren."

**Sprachen:** alle 10 (en, de, es, fr, it, pt, ja, zh, ru, ko) — 169 neue Schlüssel, davon rund
50 Laien-Erklärungen. Platzhalter-Konsistenz über alle Sprachen maschinell geprüft.

**Architektur (für spätere Änderungen):**

- `TPAnalysis` (oben in `app.js`, vor `PortfolioChart`): reine Rechenlogik ohne React/DOM.
  Ein Aufruf `TPAnalysis.analyze({ data, viewStart, viewEnd, logScale, ma200Override })` liefert
  alles in **Kerzen-Index + Preis**, nie in Pixeln. Verhältnisse werden in Log-Preisen gerechnet,
  dadurch verhalten sich Schwellen bei RUNE (~$1) und BTC (~$60.000) gleich.
- Pivots per ZigZag mit **automatischer, ATR-abhängiger Schwelle** (aus 14 Stufen wird die
  kleinste gewählt, die höchstens N Wendepunkte liefert) — drei Auflösungen: grob für Elliott,
  mittel für Muster/Trend, fein für S/R und RSI-Divergenz.
- UI-Teil in `PortfolioChartInner` unter „rune.watch Pro" (neue Prop `allowAnalysis`, an den vier
  Aufrufstellen der beiden Charts gesetzt). Zeichnet ins vorhandene Haupt-SVG über `xScale`/
  `yScale`, sitzt damit automatisch richtig nach Zoom, Verschieben und im Log-Modus.
- Übersetzungen als `TR_PRO` (kompaktes Array-Format je Schlüssel), wird beim Laden in `TR`
  eingespielt — `t(key, lang)` funktioniert wie überall sonst.
- Kosten: Rechenzeit ~1–3 ms pro Neuberechnung bei 300 sichtbaren Kerzen (50 Analysen über
  900 Kerzen: ~100 ms). Kein Backend, kein Worker, kein Deploy-Schritt.

**Paket kostenpflichtig machen (später):** Alles hängt an `allowAnalysis` (Prop) und
`analysisOn` (State). Eine Freischaltung ließe sich an genau einer Stelle einhängen — dort, wo
`analysisActive` gebildet wird — z. B. gegen einen Server-Check mit der Wallet-Adresse.

**Betroffene Dateien:** `app.js` (Engine, UI, Übersetzungen), `index.html` (CSS für Badge,
Knopf, Panel, Popover)

---

## 9. PC: Zoomen im Chart mit dem Mausrad ging nicht

**Problem:** Punkt 2 hatte den Zoom an Strg/Cmd+Rad bzw. die Trackpad-Kneif-Geste gebunden,
damit senkrechtes Trackpad-Wischen die Seite scrollt statt den Chart zu zoomen. Das hat aber
jede normale **Maus mit Rad** ausgesperrt: Am PC ohne Zusatztaste passierte beim Scrollen über
dem Chart gar nichts — und niemand hält beim Zoomen Strg gedrückt, wenn TradingView es ohne
kann.

**Fix (`handleWheel`):** Ein Mausrad wird jetzt vom Trackpad unterschieden und zoomt ohne
Zusatztaste; Trackpad-Wischen bleibt Seiten-Scroll. Drei Merkmale, das erste zutreffende zählt:

- `deltaMode != 0` (Zeilen/Seiten statt Pixel) meldet nur ein Mausrad (Firefox).
- `wheelDeltaY` (nicht standardisiert, aber in Chrome/Edge/Safari vorhanden): ein Mausrad
  liefert Vielfache von 120 pro Rastung, ein Trackpad exakt `-3 × deltaY`. Ein Trackpad-Wert von
  40 ergäbe zwar auch 120 — genau den schließt der zweite Vergleich aus.
- Rückfall ohne `wheelDeltaY`: ganzzahliges `deltaY ≥ 50`, kein `deltaX`-Anteil, mindestens
  30 ms seit dem vorherigen Event. Trackpads liefern dichte Folgen kleiner, gemischter Werte.

Zeilen-Modus wird auf Pixel normiert (×33), sonst wäre eine Firefox-Rastung kaum spürbar.
Shift+Rad verschiebt weiterhin waagerecht, Strg/Cmd+Rad und Kneif-Geste zoomen wie bisher,
Safari-`gesturechange` unverändert.

**Bewusst unverändert:** senkrechtes Trackpad-Wischen ohne Taste wird nicht abgefangen (kein
`preventDefault`) — der ursprüngliche Grund für Punkt 2 bleibt gewahrt.

**Betroffene Dateien:** `app.js`

---

## 10. Node-Karte: Prüfung von Bewertung, Rang und Churn-Logik

Auf Wunsch die gesamte Karte gegen die THORNode-API und die Churn-Regeln von THORChain
durchgesehen. Sieben Befunde, alle behoben:

1. **Rang-Tooltip zeigte falsche Gewichte.** Er nannte „Slash 30 % / Sync 25 % / Betreiber
   20 % / Bond 15 % / Version 10 %" und ließ den Faktor „Sperrungen" ganz aus — gerechnet wurde
   aber 25/20/20/20/10/5 (mit Sperr-Verlauf) bzw. 35/30/20/10/5. Rang und Erklärung
   widersprachen sich. Jetzt gibt es **eine** Gewichte-Tabelle (`gewichte`), aus der Bewertung,
   Aufklapper und Tooltip gleichermaßen lesen.
2. **Perzentil mit Gleichständen war verzerrt.** Es zählte nur, wie viele Nodes schlechter sind.
   Bei 58 von 60 Nodes mit 0 Slash Points bekamen alle 58 nur 1/60 statt ~0,5 — ein Faktor mit
   vielen Gleichständen fiel damit praktisch aus der Bewertung heraus. Jetzt Mid-Rank-Perzentil:
   Gleichstände teilen sich den mittleren Rang; wer als Einziger schlechter ist, bleibt unten.
3. **Fehlende Sync-Daten galten als perfekt.** Eine Node ohne `observe_chains` ging mit
   Rückstand 0 ein und rutschte nach oben. Jetzt neutral (0,5), und nur Nodes mit Daten bilden
   die Verteilung.
4. **Sync bestrafte Melde-Jitter.** Die Nodes melden ihre Kettenhöhen zu verschiedenen
   Zeitpunkten; auf schnellen Ketten (ETH, BSC, AVAX) liegen zwei gesunde Nodes deshalb fast
   immer 1–2 Blöcke auseinander. Jetzt Toleranz von 2 Blöcken je Kette.
5. **„Schlechteste Node" ohne Schwelle.** Die Node mit den meisten Slash Points galt als
   Churn-Abgang, selbst bei 8 Punkten. THORChain churnt nur ab `MinSlashPointsForBadValidator`
   (100) — jetzt ebenso.
6. **`leave_height` wurde nicht geprüft**, obwohl der Kommentar in der Karte es behauptete.
   Jetzt gilt eine aktive Node mit `leave_height > 0` als Abgang („leaving"), auch ohne eines
   der beiden Flags. Bond für „niedrigster Bond" über `nodeBondRaw` (total_bond, sonst
   Provider-Summe) — dieselbe Reihenfolge wie in der Karte.
7. **Median bei gerader Anzahl** nahm einen der beiden mittleren Werte statt ihres Mittels.

Was **unverändert** und geprüft richtig ist: Bond aus den Bond-Providern (÷ 1e8), eigene Node
über Provider-Abgleich mit Schwelle > 1 RUNE, „gesperrt" nur bei `release_height` in der
Zukunft, Versionsvergleich numerisch, Zielversion erst ab zwei Nodes, „erstmals aktiv" über den
Verlauf, Rang und Balkenreihe zählen nur aktive Nodes.

**Betroffene Dateien:** `app.js`

---

## 11. Ø-Kaufpreis im RUNE-Chart ignorierte „Werte verbergen"

**Problem:** Die Ø-Kaufpreis-Referenzlinie im RUNE-Preis-Chart (die kleine Box „Ø $X,XX" links
neben der Preisachse, plus eine gestrichelte Linie quer durchs Chart) hing nur an den
vorhandenen Kaufdaten — sie ignorierte den „Werte verbergen"-Schalter komplett, obwohl
überall sonst in der App (Portfolio-Wert, Bond-Rewards, Node-Bond …) bei aktivem Schalter
`••••` steht. Wer den Bildschirm teilt oder einen Screenshot macht, hätte dabei versehentlich
seinen tatsächlichen Einstandspreis preisgegeben.

**Fix:** Der Wert wird jetzt genau wie überall sonst behandelt — bei aktivem „Werte
verbergen" wird `null` statt des echten Preises an den Chart übergeben, an beiden Stellen, an
denen der RUNE-Preis-Chart aufgerufen wird (Hochformat-Modal und Vollbild-Querformat).

**Nebenbefund beim Prüfen:** Die durchgehende gestrichelte Linie selbst war nur für den
Linien-Chart-Modus verdrahtet, nie für den Kerzen-Modus — dem einzigen Modus, den der
RUNE-Preis-Chart tatsächlich verwendet. Die kleine Box-Beschriftung erschien dadurch zwar auch
auf dem Kerzen-Chart (sie hängt nicht vom Chart-Typ ab), die Linie selbst aber nicht. Jetzt auch
im Kerzen-Zweig ergänzt, damit beide Elemente konsistent da sind — und beide konsistent
verschwinden, wenn man sie verbergen will.

**Betroffene Dateien:** `app.js`

---

## 12. Node-Karte: Diagnose je Node (wie in den Node-Scannern)

Auf Wunsch („ich will alles über die Nodes wissen, einfach und strukturiert"): Die
Detailansicht einer angetippten Node zeigt jetzt zusätzlich drei kompakte Chip-Zeilen — alles
direkt aus `/thorchain/nodes`, nichts geschätzt:

- **Ketten-Sync** — je beobachteter Kette der Rückstand zum Netzwerk-Maximum, genau wie die
  „OK / −143"-Spalten der bekannten Telegram-Node-Scanner: `BTC OK`, `ETH −143`. Farbe nach
  **Zeit**, nicht nach Blöcken (3 Blöcke BTC sind eine halbe Stunde, 3 Blöcke AVAX sechs
  Sekunden): grün = innerhalb der Melde-Toleranz, gelb = bis 10 Minuten, rot = darüber. Tooltip
  mit Blöcken und Zeit. ⓘ erklärt für Laien, was das bedeutet (Swaps auf dieser Kette werden
  durch diese Node verzögert).
- **Zustand** — Sperre mit Restzeit und Grund („gesperrt, noch ~50 min · failed to perform
  keygen"), Wartungsmodus, Austritt beantragt/erzwungen, Austritt-Block, bei wartenden Nodes
  die Startprüfung (Preflight-Status samt Grund, z. B. „node account does not have minimum
  bond"), Version gegen Zielversion („v3.5.0 → Ziel v3.6.0"). Ist nichts davon aktiv: „OK".
- **Fakten** — Vaults (Anzahl Asgard-Vaults, die die Node mitsigniert; 1 = erster aktiver
  Zyklus, ⓘ erklärt es), Reward dieser Churn (`current_award`, bei „Werte verbergen" ••••),
  Slash Points (rot ab 100, gelb ab 20), IP-Adresse.

Der Balken-Tooltip in der Reihe nennt zusätzlich die Ketten im Rückstand („ETH −500"), damit
man Problem-Nodes findet, ohne jede einzeln anzutippen.

**Betroffene Dateien:** `app.js`

---

## 13. Node-Karte: Suchleiste und Sync-Bewertung nach Zeit

**Suchleiste** (auf Wunsch): Eingabefeld über der Balkenreihe. Findet Nodes nach
Adress-Anfang oder -Ende (mit oder ohne „thor1"), Betreiber-Adresse und IP. Alle Treffer werden
in der Reihe gold gestrichelt hervorgehoben, der erste wird ausgewählt und in Sicht gescrollt —
die Detailansicht mit der Diagnose steht sofort darunter. Trefferzahl bzw. „kein Treffer"
daneben, × leert die Suche.

**Sync-Bewertung nach Zeit** (Frage: „fließt die Ketten-Diagnose in die Bewertung ein?"):
Bisher ging nur der schlechteste Rückstand in **Blöcken** in den Rang — 30 Blöcke BTC
(5 Stunden) und 30 Blöcke AVAX (eine Minute) zählten gleich. Jetzt wird der Rückstand je Kette
über die Blockzeit in **Sekunden** umgerechnet, und jede *weitere* hängende Kette bringt einen
Aufschlag von 2 Minuten: eine Node, die auf vier Ketten hinterherhinkt, steht schlechter da als
eine mit demselben Maximum auf einer. Die Anzeige („498 Blöcke zurück") bleibt in Blöcken, nur
die Bewertung rechnet in Zeit.

Was bewusst **nicht** in den Rang einfließt: Startprüfung, Austritt, Wartungsmodus, Vaults,
Reward, IP — das sind Zustände bzw. Fakten, keine Qualitätsmerkmale. Sie stehen in der
Diagnose, nicht in der Note.

**Betroffene Dateien:** `app.js`

---

## 14. Node-Karte: Warnsignale, Betreiber-Filter, Vaults-Chip entfernt

**Warnsignale** (auf Wunsch: „man muss auf den ersten Blick wissen, wer gerade Probleme
macht"): Eigener Block zwischen Kennzahlen und Detailansicht. Jede aktive Node bekommt einen
Schweregrad 0–3 mit Gründen:

- **3 — schadet dem Netzwerk jetzt:** eine Kette 10+ Minuten im Rückstand, Sperre, erzwungener
  Austritt, Slash ≥ 300
- **2 — ernst:** Slash ≥ 100, mehrere Ketten gelb (Minuten zurück)
- **1 — Hinweis:** eine Kette gelb, alte Version, Wartungsmodus, Slash > 20

Der Block listet Nodes ab Stufe 2, schlimmste zuerst, mit Kurzadresse, Betreiber und Grund
(„GAIA −69842 · Slash 975 · jail: failed to perform keygen"). Darüber stehen **Betreiber**, bei
denen mindestens zwei Nodes betroffen sind („Betreiber …k6jt — 5 von 7 Nodes mit Problemen").
Ein Tipp auf eine Node öffnet sie, ein Tipp auf einen Betreiber übernimmt ihn in die Suche.
Ist nichts los: „✓ gerade macht keine Node Probleme". In der Balkenreihe bekommen Problem-Nodes
eine rote (Stufe 3) bzw. gelbe (Stufe 2) Unterkante; der Tooltip nennt die Gründe.

**Betreiber-Filter:** Die Suche *filtert* die Reihe jetzt statt nur hervorzuheben — bei einer
Betreiber-Adresse bleiben nur seine Nodes stehen. Gilt für alle Suchen (Adresse, Betreiber, IP).

**Vaults-Chip entfernt:** Im echten Betrieb stand dort „Vaults 154" — `signer_membership`
zählt offenbar auch längst aufgelöste Vaults. Lieber keine Zahl als eine falsche; die
„Erstling"-Erkennung läuft ohnehin bevorzugt über den gespeicherten Verlauf.

**Betroffene Dateien:** `app.js`

---

## 15. Warnsignale v2: relative Schwellen, robuste Ketten-Referenz, kompakt

Mit echten Daten war Punkt 14 unbrauchbar: **91 von 91 Nodes** galten als Problem, dazu
Rückstände wie „BASE −6409662". Drei Ursachen, alle in der Bewertung, nicht nur in der Anzeige:

1. **Slash-Punkte absolut** (≥ 100 = Problem) war falsch. Im Churn-Zyklus haben *alle* Nodes
   hunderte bis tausende Punkte — das ist der Normalzustand, nicht ein Fehler. Jetzt zählt
   Slash **relativ zum Median** der aktiven Nodes: ≥ 3× Median (und ≥ 300) = kritisch — so
   bewertet THORChain selbst „bad validators", Score gegen den Durchschnitt —, ≥ 2× (und ≥ 100)
   = ernst, ≥ 1,5× = Hinweis. In der Anzeige steht das Vielfache dazu („Slash 3000 (3,7×)").
2. **Ketten-Referenz = höchste gemeldete Höhe** war zerbrechlich: Eine einzige Node mit
   falscher oder vorauseilender Höhe machte alle anderen „hinterher". Jetzt **Median** der
   Nodes, die die Kette wirklich melden. Und **Höhe 0 = Kette nicht beobachtet** — vorher
   „−6409662 Blöcke zurück", jetzt „–" (keine Daten), zählt nirgends mit.
3. **Kettenweites Hängen:** Hängen ≥ 40 % der aktiven Nodes auf derselben Kette, ist es die
   Kette (oder deren Referenz), nicht die einzelne Node — zählt nicht gegen sie, wird aber als
   Hinweis genannt („Kettenweit, zählt nicht gegen einzelne Nodes: TRON").

**Darstellung:** eingeklappt eine Zeile — „⚠ Warnsignale · 2 kritisch · 1 ernst · 1 Betreiber"
(oder „✓ gerade macht keine Node Probleme") —, Tipp klappt auf: höchstens 3 Betreiber (nur wenn
mindestens 2 Nodes *und* mindestens die Hälfte betroffen), höchstens 5 Nodes, „+n weitere" per
Tipp. Dieselben relativen Schwellen gelten für die farbigen Unterkanten in der Reihe.

**Betroffene Dateien:** `app.js`

---

## 16. Node-Karte: Problem-Nodes leuchten, Suche ohne Eigen-Styling

- **Aufleuchten statt Unterkante:** Problem-Nodes sind jetzt der ganze Balken in Farbe — Stufe 3
  rot mit Puls (CSS-Animation, bei „Bewegung reduzieren" statisch), Stufe 2 gelb mit ruhigem
  Glow. Die eigene Node bleibt Cyan, bekommt bei Problemen aber denselben Glow. Unter der Reihe
  eine Legende „● kritisch ● ernst", nur wenn es Problem-Nodes gibt.
- **Suche ohne Eigen-Styling:** Bei aktiver Suche ist die Reihe *nur* Treffer. Die eigene Node
  bekam bisher trotzdem Cyan und Glow und sah dadurch nicht wie ein Treffer aus (gemeldet:
  „mein Node steht noch da, verwirrend" — sie *war* ein Treffer, weil der gesuchte Betreiber ihr
  Betreiber ist). Jetzt wird sie in der Suche wie jeder andere Treffer gestrichelt markiert;
  ohne Suche wieder Cyan.

**Betroffene Dateien:** `app.js`, `index.html` (CSS `.tp-node-warn3` / `.tp-node-warn2`)

---

## 17. Volle RUNE-Historie aus CoinGecko — wieder entfernt

Auf Wunsch („CoinGecko-Kerzen aus dem Monatschart rausnehmen, brauche ich nicht") vollständig
zurückgebaut: keine CoinGecko-Aggregation, keine vorangestellten Kerzen, der Ausreißer-Filter
arbeitet wieder wie im Original, die Fußzeile „Historie ab …" ist weg. Wochen- und Monatskerzen
kommen wie zuvor ausschließlich von Binance (ab September 2020).

## 18. Prognose 1–4 Jahre — wieder entfernt

Auf Wunsch („Mach die Prognose komplett raus. Gefällt mir nicht") vollständig zurückgebaut:
keine Langfrist-Pfade in der Engine, kein Korridor, kein 4-Jahres-Knopf, kein Tabellen-Abschnitt,
keine y-Skalen-Erweiterung, keine Übersetzungen dazu. Die drei Engine-Korrekturen, die dabei
entstanden, bleiben, weil sie unabhängig davon richtig sind: Log-Mathematik bei großen Spannen
(samt Kontext), keine 60×-„Welle A", Welle 3 darf bis 14× so lange dauern wie Welle 1. Ebenso
bleibt die volle Historie (Punkt 17) und der Hinweis „Historie ab …" in der Fußzeile.

Was bleibt: die kurzfristigen Szenarien nach dem Ziel (Nachtrag 17/18/19) mit Legende-Box.

---

## 19. Node-Karte: Suche zeigt nur das Suchergebnis

Gemeldet: „Wenn man sucht und jemanden findet, muss nicht die Übersicht zu sehen sein, wo man
selber bondet — das ist verwirrend." Richtig: Rang, eigener Bond, Slash Points, Churn-Gruppen
und der Warnsignale-Block beschreiben die **eigene** Node bzw. das Gesamtnetz, nicht den
Treffer. Bei aktiver Suche sind sie jetzt ausgeblendet; an ihrer Stelle steht eine Trefferzeile:
„Suchergebnis · 3 Treffer · von 60 aktiven Nodes · ⚠ 3 mit Problemen" und ein Knopf „zurück zur
Übersicht". Die Reihe zeigt weiterhin nur die Treffer, die Detailansicht darunter den ersten
davon. Leert man die Suche (× oder der Knopf), ist die Übersicht sofort wieder da.

**Betroffene Dateien:** `app.js`

---

## 20. Andere Werte im Chart bei fremder Anzeigewährung + Absturzschutz

**Gemeldet von Nutzern:** „Auf dem Handy bekomme ich andere Werte im 1D-Chart" — der Melder
hatte EUR als Anzeigewährung. Ursache gefunden: Bei der Notierung „USD" rechnet die App die
Binance-Kerzen in die eingestellte Anzeigewährung um (EUR, GBP …), die Kopfzeile schrieb aber
stur **„RUNE / USD"**. Wer seine EUR-Zahlen mit einem USD-Screenshot verglich, sah zwangsläufig
„falsche" Werte — dabei stimmten beide, nur in verschiedenen Währungen.

**Fix:** Die Kopfzeile und der Notierungs-Wähler zeigen jetzt die Währung, in der die Zahlen
tatsächlich sind („RUNE / EUR"), plus den Hinweis „in EUR umgerechnet, aktueller Kurs". Der
Zusatz ist wichtig und ehrlich: Umgerechnet wird mit dem **heutigen** Wechselkurs, auch für alte
Kerzen — eine Näherung, kein historischer EUR-Kurs. Wer exakt vergleichbare Zahlen will, stellt
die Anzeigewährung auf USD.

**Absturzschutz:** Ebenfalls gemeldet („es kommt häufig zu Bugs, die zu einem Absturz führen").
Bisher fing nur die globale ErrorBoundary — ein Fehler irgendwo in der Chart-Analyse ersetzte
damit die **ganze Seite** durch „Something went wrong". Jetzt laufen das Zeichnen des Overlays
und das Analyse-Panel in eigenen Fehlergrenzen: Ein Fehler nimmt nur die Analyse mit, Chart,
Portfolio und Node-Karte bleiben benutzbar; die Ursache steht als Warnung in der Konsole.

**Betroffene Dateien:** `app.js`

---

## 21. Anonyme Besucher-Zählung (Frontend-Teil)

**Befund zuerst:** Die bisherige Statistik zählt ausschließlich Nutzer **mit eingetragener
Wallet** — `recordSyncActivity` steckt nur in `/purchases`, `/wallets`, `/drawings` und
`/swap-history`, und alle vier brauchen `wallets[0]`. Wer nur Chart, Node-Karte oder Swap
benutzt, taucht dort nie auf. Außerdem wird pro Nutzer nur die **erste** Wallet gezählt, und die
Ausschluss-Liste (`STATS_EXCLUDED_ADDRESSES`) wirkte bisher nur beim Schreiben, nicht beim Lesen.

**Frontend-Teil (in diesem Paket):** Beim ersten Besuch erzeugt der Browser eine Zufallszahl
(`crypto.randomUUID`, gekürzt auf 24 Zeichen), legt sie unter `tp_visitor` im localStorage ab
und hängt sie an den `/volume`-Aufruf (`?v=…`). Keine IP, kein Fingerprint, keine Wallet, kein
Cookie. Schlägt localStorage fehl (privater Modus), wird schlicht nichts gezählt.

Ehrlich zu den Grenzen: Das zählt **Geräte**, nicht Menschen — Handy und PC sind zwei. Wer
Browserdaten löscht oder privat surft, zählt beim nächsten Besuch erneut; die Zahl ist eher eine
Obergrenze.

**Worker-Teil:** siehe `worker-aenderungen.md` im Paket — Migration (`visitor_days`), Erfassung
in `/volume`, zweite Stats-Seite zum Wischen, „Aktive Adressen" fest auf 24 h, und die
Ausschluss-Liste jetzt auch beim Lesen.

**Betroffene Dateien:** `app.js`, `worker-aenderungen.md` (neu)

---

## 22. Node-Karte: Kennzahlen folgen der angetippten Node

Gemeldet: „Wenn ich im Graphen eine Node anklicke, müssen darunter auch deren Werte stehen und
nicht die Node, wo man selber gebondet ist." Richtig — wer eine fremde Node antippt, will deren
Rang sehen, nicht den eigenen.

Beim Antippen zeigen Rang, Perzentil, Bond und Slash Points jetzt die **ausgewählte** Node. Die
Kachel heißt dann „Bond" statt „Dein Bond", und der fremde Bond wird nicht durch „Werte
verbergen" maskiert — er steht ohnehin öffentlich in der Kette; verborgen wird der eigene. Über
der Suchleiste steht „→ Werte der ausgewählten Node …x042" mit einem Knopf „zurück zu meiner";
das × an der Detailansicht tut dasselbe.

Nachtrag: Platz, Bond und Slash standen damit doppelt — groß oben als Kennzahlen und noch
einmal klein in der Detailzeile. Die Detailzeile trägt jetzt nur noch, was oben NICHT steht:
Sync, Betreiber, Alter, Version, Status.

**Betroffene Dateien:** `app.js`

---

## 23. Volumen-Seite: Handelsplätze im Vergleich (THORChain / Chainflip / NEAR Intents)

Auf Wunsch, mit Vorlage aus dem RUNE-Tools-Repo (`ThorchainDominance.svelte`). Neue Karte auf
der Volumen-Seite, direkt unter dem Volumen-Chart: Balken je Handelsplatz mit Betrag und Anteil,
umschaltbar zwischen **24h**, **7 Tagen** und **30 Tagen**.

**Warum die Zahlen stimmen — vier Entscheidungen:**

1. **THORChain aus Midgard, nicht aus DefiLlama.** Auf Wunsch — und aus der Praxis bestätigt:
   DefiLlamas THORChain-Adapter lieferte keine verwertbare Reihe, die Zeile fehlte in der Karte
   komplett. Midgard ist für THORChain die Primärquelle: exakt, dokumentiert, taggenau. Für
   Chainflip und NEAR Intents gibt es keine dokumentierte öffentliche Volumen-API, dort bleibt
   DefiLlama.
2. **DefiLlama wird für THORChain gar nicht mehr abgefragt** (auf Wunsch). Die Quelle steht an
   jeder Zeile („Midgard" bzw. „DefiLlama"), und die Fußzeile sagt ausdrücklich, dass
   verschiedene Quellen verschieden zählen und der Abstand deshalb mit Vorsicht zu lesen ist.
3. **Gemeinsamer Stichtag, ohne den laufenden Tag.** Verglichen wird der letzte **abgeschlossene**
   UTC-Tag, den alle Reihen haben. Midgard führt den laufenden Tag bereits mit einem Teilwert —
   der würde THORChain künstlich klein aussehen lassen und wird deshalb ausgeschlossen. 7d/30d
   summiere ich selbst aus der Tagesreihe, damit alle drei exakt dieselben Tage umfassen.
4. **Lücken werden nicht aufgefüllt.** Fehlt einem Platz ein Tag, wird er nicht als 0 gezählt
   (das drückte den Schnitt), sondern die Zeile trägt den Hinweis „nur 28 von 30 Tagen
   vorhanden".


Zusätzlich **Einnahmen** und ein **Vergleichschart**:

- **Umschalter Volumen / Einnahmen.** Einnahmen heißt: was Nutzer an Gebühren zahlen —
  THORChain aus Midgard (`/history/earnings`, Liquidity Fees in RUNE, umgerechnet mit dem
  **RUNE-Preis desselben Tages**, nicht dem heutigen; sonst verzerrt jede Kursbewegung die
  Historie rückwirkend), Chainflip und NEAR Intents aus DefiLlama
  (`/summary/fees/<slug>`, `dataType=dailyFees`). **Block Rewards bleiben draußen** — das ist
  frisch emittierter RUNE, kein Umsatz; wer sie mitzählt, vergleicht Emission mit
  Handelsgebühren.
- **Chart-Knopf** in der Kopfzeile öffnet den 30-Tage-Verlauf: zwei Diagramme untereinander
  (Volumen und Einnahmen), eine Linie je Handelsplatz, mit Legende und Datumsbereich.
- **Gebühren nach THORChain-Logik** (auf Wunsch). Midgards `liquidityFees` ist der Anteil der
  Swap-Gebühr, der an die **Liquiditätsseite** geht. DefiLlama führt genau diese Größe als
  `dailySupplySideRevenue` — bei NEAR Intents sind das die Solver, bei Chainflip die Liquidity
  Provider. Verglichen wird jetzt diese Größe, nicht mehr `dailyFees`.

  Der Unterschied ist erheblich: `dailyFees` enthält bei NEAR Intents laut DefiLlamas eigener
  Einkommensrechnung auch die Anteile für **Solver und Distributionskanäle** — Midgards
  `liquidityFees` enthält weder Affiliate-Gebühren noch Outbound-Gas. Deshalb sah NEAR Intents
  vorher übergroß aus. Am Umschalter steht, worauf der Vergleich beruht: „Liquiditätsseite
  (THORChain-Logik)". Die Zusatzzeile „Nutzer zahlen insgesamt" wurde auf Wunsch wieder
  entfernt — sie fehlte für THORChain ohnehin und nahm nur Platz weg; die Erklärung dazu steht
  im ℹ.

- **Negative Werte abgefangen** (gemeldet: NEAR Intents mit −$13,8k). Bei DefiLlama kann die
  Supply-Side negativ werden — dann hat die Liquiditätsseite (bei NEAR die Solver) in dem
  Zeitraum unterm Strich draufgezahlt, oder der Adapter verrechnet Anreize gegen die Gebühren.
  Die Zahl ist echt, taugt aber nicht als Anteil: Die Prozente summierten sich zu
  61 + 57 − 18 = 100 und sahen aus wie ein Rechenfehler. Jetzt werden Anteile nur aus den
  **positiven** Werten gebildet; negative Zeilen erscheinen ohne Balken, ohne Prozentwert, in
  Warnfarbe und mit Hinweis — Erklärung im ℹ.
- **Feinschliff nach Rückmeldung:** Titel heißt englisch jetzt „Cross-chain venues compared"
  („Venue comparison" war zu kryptisch), das ℹ ist ein Icon im Stil des Chart-Knopfs statt eines
  Emoji-Zeichens, und das **Datum steht nur beim Tageswert** — bei 7 und 30 Tagen wäre ein
  einzelnes Datum irreführend, dort steht der Stichtag im ℹ.
- **Infofenster: zentriert, mit vollständiger Verteilung.** Das ℹ öffnet ein Fenster in der
  Mitte (wie der Vergleichschart), darin ein Abschnitt je Handelsplatz mit Quelle, Verteilung
  der Gebühren und einer Zeile zur Token-Menge.

  **THORChain — Anteile am System Income, Summe genau 100 %** (Mimir-Parameter in der Kette,
  recherchiert und gegen die Tagesdaten geprüft):

  | Anteil | Empfänger |
  |---|---|
  | 59 % | Nodes und Pools (Incentive Pendulum) — wie sich das teilt, wird **gemessen**, nicht behauptet: der Worker summiert `bondingEarnings` und `liquidityEarnings` der letzten 30 Tage aus Midgard und die App schreibt das Ergebnis dahinter (steht das Pendulum ganz auf Nodes, steht dort „100 % Nodes, 0 % Pools") |
  | 20 % | Protocol Owned Liquidity (neu seit 1.9.2026) |
  | 10 % | TCY-Staker |
  | 5 % | Entwickler-Fonds |
  | 5 % | Marketing-Fonds |
  | 1 % | verbrannt (bis 12.9.2026 waren es 5 %) |

  Nominell teilt das Incentive Pendulum diese 59 % zwischen Nodes und Pools — gemessen (Midgard
  `bondingEarnings` gegen `liquidityEarnings`, 30 Tage) kommt bei den Pools derzeit nichts an,
  deshalb steht dort schlicht „Nodes". Kommt wieder etwas bei den Pools an, schreibt die App den
  Anteil automatisch dazu; behauptet wird nichts.

  Zwei Parameter haben sich gerade erst geändert: `POLRESERVESYSTEMINCOMEBPS` auf 2000 (1.9.2026)
  und `SYSTEMINCOMEBURNRATEBPS` von 500 auf 100 (12.9.2026). Wer noch mit „75 % Nodes/Pools,
  5 % Burn" rechnet, liegt seit zwei Wochen daneben.

  **Token-Menge:** THORChain nicht inflationär (Emission Feb 2025 von 25.000 auf 2 RUNE pro Tag,
  dazu 1 % Burn). Chainflip bisher inflationär — die feste Emission für Validatoren übertrifft
  die Burns. NEAR von der Protokollauslegung her inflationär, der Rückkauf wirkt dagegen.

  **Nakamoto-Koeffizient** (auf Wunsch), mit **beiden Schwellen**, weil sie Verschiedenes
  bedeuten: Ein Drittel des Bonds reicht, um den Konsens zu **stoppen** (die übliche
  Nakamoto-Definition für BFT-Ketten), für die Verfügung über die Vaults braucht es zwei
  Drittel. In der Box steht deshalb „von 48 Betreibern könnten 4 die Kette blockieren …,
  15 sie kontrollieren …". Gezählt **je Betreiber** (ein Betreiber mit zehn Nodes ist ein
  Akteur), gerechnet aus den Bonds der aktiven Nodes, die die App ohnehin lädt.

  Bei Chainflip steht statt einer Zahl die Struktur: bis zu 150 Validatoren, die Plätze gehen in
  einer 28-Tage-Auktion an die Höchstbietenden. Bei NEAR Intents „nicht offengelegt" — niemand
  veröffentlicht, wie viele Solver es gibt und wie sich das Volumen auf sie verteilt.

  **Ehrlich zu den anderen beiden:** Eine vollständige, veröffentlichte Aufteilung gibt es dort
  nicht — aufgeführt ist, was die Protokolle und DefiLlama dokumentieren. Bei NEAR Intents
  behalten die Solver ihren Spread, feste Prozentsätze nennt niemand. Zur Dezentralisierung
  steht bewusst nichts mehr: Das lässt sich nicht in einer Zeile fair abbilden.

---

## 24. Monatschart: Kurse ab Juli 2019 (feste Tabelle)

Binance-Spot beginnt im September 2020, gehandelt wird RUNE seit Juli 2019 — auf dem
Monatschart fehlte damit der komplette erste Zyklus.

**Vier Anläufe über APIs sind gescheitert, und zwar so:**

| Quelle | Ergebnis |
|---|---|
| CoinGecko `ohlc?days=max` | nur mit Bezahlplan |
| CoinGecko `market_chart?days=max` | „Public API users are limited to … the past 365 days" |
| CoinGecko vom Worker aus | HTTP 403 — Rechenzentrums-IPs werden abgewiesen |
| CryptoCompare `fsym=RUNE` | liefert eine **andere Münze** (Kurse um 1.000 USD) |
| TradingView `CRYPTO:RUNEUSD` | lizenzierter Index, keine offene Schnittstelle |

**Jetzt: feste Tabelle im Code.** 14 Monatskerzen von Juli 2019 bis August 2020, abgelesen aus
Yahoo Finance (RUNE-USD, Monatsansicht). Diese Kurse ändern sich nie wieder — also gehören sie
in den Code und nicht in einen Abruf, der ausfallen kann. Kein Worker, keine Fremd-API, nichts,
was 403 wirft.

Grenzen, offen benannt:

- **Nur der Monatschart.** Die Tabelle enthält Monatswerte; sie auf Wochen aufzuteilen hieße,
  einen Verlauf innerhalb des Monats zu erfinden.
- **Kein Volumen** im frühen Bereich; die Balken bleiben dort leer.
- **Es wird nichts überschrieben:** Ergänzt wird nur, was vor der ersten Binance-Kerze liegt,
  und die Plausibilitätsprüfung an der Nahtstelle bleibt aktiv.

Die markanten Punkte stimmen mit den bekannten Eckdaten überein: Allzeittief $0,0079 im
September 2019, Anstieg von $0,13 (Juni 2020) auf $1,03 (August 2020).

**Betroffene Dateien:** `app.js`

---

## 25. Die Wellenkarte reicht jetzt über den ganzen Chart

Gemeldet: „Das Analyse-Tool muss auf den ganzen Chart greifen." Auf dem Monatschart seit 2019
beschrieb die Zählung nur das Ende — der komplette erste Zyklus blieb unbeschriftet.

Zwei Ursachen, beide behoben:

1. **Die Kette der früheren Strukturen lief genau einmal.** Sie geht jetzt bis zu sechs
   Segmente rückwärts weiter, bis der Anfang des Fensters erreicht ist oder nichts mehr
   zählbar bleibt.
2. **Im frühen Bereich reichten die groben Wendepunkte nicht.** Auf der 60-%-Stufe ist der
   Anstieg 2019–2021 ein einziges Segment ohne Umkehr — daraus lässt sich keine Struktur
   bilden. Findet sich dort nichts, wird jetzt auf die mittleren und notfalls die feinen
   Wendepunkte ausgewichen.

Im Test mit Monatsdaten 2019–2026 deckt die Wellenkarte damit **98 % des Charts** ab; der
Aufstieg bis zum Hoch 2021 wird als eigene Struktur gezählt (0-1-2-3-4-5-A-B-C) statt leer zu
bleiben.

**Betroffene Dateien:** `engine.js` → `app.js`

---

## 26. Regelwerk gegen Frost/Prechter abgeglichen

Auf Wunsch die Regeln Punkt für Punkt geprüft (Frost & Prechter, „Elliott Wave Principle",
dazu die Regellisten von Elliott Wave Gold und XForceGlobal).

**Schon vorher korrekt umgesetzt** — alle drei unverrückbaren Regeln:

- Welle 2 geht nie über den Start von Welle 1 hinaus
- Welle 3 geht immer über das Ende von Welle 1 hinaus und ist nie die kürzeste
- Welle 4 dringt nicht in den Bereich von Welle 1 (Ausnahme: Diagonale)

**Zwei Lücken gefunden und geschlossen:**

1. **Truncation von Welle 5 wurde stillschweigend verworfen.** Nach Frost/Prechter ist sie
   erlaubt — selten, und ein Warnzeichen für Schwäche vor der Umkehr. Bisher fiel jede solche
   Zählung heraus, was auf echten Daten Strukturen unsichtbar machte. Jetzt wird sie gezählt,
   in der Regelprüfung als „Welle 5 verkürzt (erlaubt, selten)" ausgewiesen und im Punktwert
   abgewertet, damit eine reguläre Zählung vorgeht. Grenze: höchstens **3 %** unter dem Ende von
   Welle 3 — Frost/Prechter schreiben „usually by very slim margins", und mit den ursprünglich
   gewählten 10 % verdrängte eine verkürzte Welle 5 saubere Zählungen, bei denen das Hoch
   schlicht das Ende der Bewegung war (im Chart sichtbar als Welle 5 deutlich unter Welle 3).
   Zusätzlich muss Welle 5 über Welle 4 hinausgehen.
2. **Beim kontrahierenden Keil fehlte `W4 < W2`.** Ohne diese Bedingung wurde jede
   Überlappung durchgewunken, solange nur die Bewegungswellen schrumpften.

**Betroffene Dateien:** `engine.js` → `app.js`

---

## 27. Übergeordnete Zählung — top-down, auf echten Extrema

Gefragt: „Warum wird die Welle von Oktober 2019 bis Mai 2021 nicht als Welle 1 betrachtet?"

**Erster Versuch (verworfen):** römische Ziffern an die rückwärts gefundenen Vorgänger-Strukturen
hängen. Ergebnis war unbrauchbar — die Ziffern saßen dort, wo die Automatik zwei Strukturen
trennt, nicht an den großen Extrema.

**Jetzt top-down**, so wie ein Analyst vorgeht und wie es Frost/Prechter beschreiben:

1. Die **größten Wendepunkte** des Fensters bestimmen (gröbste Zickzack-Stufe, die noch vier
   Punkte trägt).
2. Darauf eine **ganz normale Elliott-Zählung** laufen lassen — dieselben drei Regeln, dieselbe
   Bewertung. Der Ausgangspunkt wird auf das äußerste Extrem im ersten Fünftel gezwungen
   (`forceStart`), sonst wählt die Bewertung die Zählung am rechten Rand.
3. Die feine Zählung beschreibt weiterhin das laufende Geschehen und liegt damit **innerhalb**
   der letzten übergeordneten Welle.

Im Test mit Monatsdaten 2019–2026: Makro zählt vom **Tief 2019** (Start) über das **Hoch 2021**
(Welle 3) zum **Tief 2025** (Welle 4); die feine Zählung beginnt danach. Gezeichnet als
durchgehender Zug mit römischen Ziffern (I–V bzw. A–C) in größeren Marken, die den
Wellennummern ausweichen. Im Panel als Zeile „Eine Ebene höher" mit ℹ.

**Zwei Funde auf dem Weg dorthin**, beide durch ein neues Diagnose-Werkzeug (`erklaereZaehlung`)
gefunden statt durch Raten — es protokolliert für eine vorgegebene Punktfolge, an welcher der
rund zwanzig Bedingungen sie scheitert:

- Die Bewertung bevorzugte die Zählung am rechten Rand, weil sie besser zum aktuellen Geschehen
  passt. Dafür gibt es jetzt `forceStart`.
- Der noch **unbestätigte letzte Schwung** (`pending`) brachte die Makro-Zählung zu Fall: Mit ihm
  scheiterte sie an den Längenregeln, obwohl die Struktur darunter gültig ist. Für die
  übergeordnete Sicht zählt nur, was als Wendepunkt feststeht.

**Nachtrag — gemeldet: „Keine Ziffern im vollen Chart".** Der erste Anlauf probierte je Stufe
genau **einen** Startpunkt. Scheiterte der an einer Nebenbedingung, gab es gar keine
übergeordnete Sicht — obwohl eine gültige existierte. Auf geglätteten Testdaten fiel das nicht
auf, auf echten schon.

Jetzt werden über **sechs Zickzack-Stufen** (0,8 bis 0,2) und **drei Startpunkte** je Stufe
(tiefster, höchster und erster Wendepunkt im ersten Viertel) alle gültigen Zählungen gesammelt;
genommen wird die mit der größten **Abdeckung** des Charts. Im Test mit einem rauen Verlauf, der
echten Daten nahekommt: 5 Wellen bis zum Allzeithoch, dann A-B-C — 83 % Abdeckung.

**Nachtrag — gemeldet: „zu viel und unübersichtlich".** Die römischen Ziffern sind jetzt eine
**eigene Ebene** und **standardmäßig aus**. Eingeschaltet wird sie über den Chip „Eine Ebene
höher" neben „Unterwellen"; die Einstellung bleibt gespeichert. Ohne sie sieht der Chart aus wie
zuvor — eine Zählung, keine zwei.

**Betroffene Dateien:** `engine.js`, `ui-block.js`, `translations-pro.js` → `app.js`

---

## Verifikation (neueste Punkte)

Frühhistorie (Punkt 24) — Funktionstest der Bündelung plus jsdom:

| Test | Ergebnis |
|---|---|
| Alle 14 Monatszeilen stehen unverändert im Build (Werte im Test ausgeschrieben) | OK |
| Jede Kerze in sich schlüssig; Allzeittief Sept 2019 = 0,0079; Anstieg 0,13 → 1,03 | OK |
| August 2020 mit echten Dochten (Hoch 1,184 / Tief 0,407) | OK |
| Monatschart: 14 Kerzen kommen dazu, erste ist Juli 2019, Binance-Kerzen unverändert | OK |
| Wochenchart, 4H/1D und RUNE/BTC bleiben unberührt | OK |
| Unplausible Nahtstelle (Faktor 500) wird verworfen | OK |
| jsdom: Monatschart zeigt „30. März 19" auf der Achse, ohne jede Netzabfrage | OK |
| Monatschart 2019–2026: Wellenkarte deckt 98 % ab, Aufstieg bis 2021 als eigene Struktur | OK |
| Schlägt der Worker fehl, greift der Direktweg zu CoinGecko | OK |
| Unplausible Reihe (Faktor ~1000 an der Nahtstelle) wird verworfen, leichter Versatz akzeptiert | OK |
| Worker: CryptoCompare-Reihe mit Median 1.050 USD wird ignoriert, CoinGecko greift | OK |
| Monatskerzen: Grad-Wahl findet wieder eine Zählung (Regel greift erst ab fünf Kerzen je Welle) | OK |

Handelsplatz-Vergleich (Punkt 23), jsdom mit gesetzten Zahlen:

| Test | Ergebnis |
|---|---|
| Zeitraum heißt „1 Tag" (letzter abgeschlossener UTC-Tag), Datum nur beim Tageswert | OK |
| Beträge und Anteile korrekt, absteigend sortiert, negative Werte ohne Balken/Prozent | OK |
| Einnahmen vergleichen die Liquiditätsseite; ℹ zeigt Quelle, Verteilung, Token-Menge, Nakamoto | OK |
| THORChain-Anteile ergeben 59+20+10+5+5+1 = 100 % | OK |
| Nakamoto: konstruierte Verteilung → 3 von 36 blockieren, 5 kontrollieren | OK |
| Chart-Fenster mit zwei Diagrammen und einer Linie je Handelsplatz | OK |

Vollständige Suite zu diesem Build: 34/34 Chart (de/en), 12/12 Frühhistorie, 3/3 jsdom-Chart,
33/33 Handelsplätze, 39/39 Node-Karte, 29/29 Engine, dazu Warnsignale, Grad-Umschalter,
Währung, Besucher, Verbergen, Wheel, Popover und Flüssigkeit — alle grün.

---

## Dateien in diesem Paket

```
app.js                         — die Anwendung (alle Änderungen, inkl. Punkt 7–24)
index.html                     — Einstieg, Cache-Busting auf den aktuellen Build
react.production.min.js        — React 18 (unverändert)
react-dom.production.min.js    — React-DOM 18 (unverändert)
_headers                       — Cloudflare-Cache-Regeln: index.html nie cachen
worker-aenderungen.md          — Änderungen für den Cloudflare-Worker, nicht Teil der Website
README.md                      — dieses Dokument
```

Der Worker liegt in einem eigenen Paket (`worker.js`, `migration.sql`, `README-worker.md`).
Reihenfolge beim Ausrollen: Migration → Worker → Website.

Dieses Paket: **build 20260918-2041**.

**Ehrlichkeit eingebaut:** Wo eine Zahl nicht belegbar ist, steht das in der App — nicht in der
README.
