# Worker-Änderungen (Cloudflare-Dashboard-Editor)

Drei Dinge:

1. **Anonyme Besucher-Zählung** über `/volume` (die App schickt ab diesem Paket ein Token mit)
2. **Zweite Stats-Seite**, zu der man wischen kann — die bisherige bleibt unverändert
3. **Aktive Adressen fest auf 24 h**, der Umschalter dort entfällt

---

## Schritt 1 — Migration (D1 → Console, einmalig)

```sql
CREATE TABLE IF NOT EXISTS visitor_days (
  token TEXT NOT NULL,
  day TEXT NOT NULL,
  first_seen_at INTEGER,
  PRIMARY KEY (token, day)
);
```

Ein Eintrag je Gerät und Tag. Kein Eintrag enthält IP, Wallet oder sonst etwas Persönliches —
nur die Zufallszahl, die der Browser selbst erzeugt hat.

---

## Schritt 2 — Besucher erfassen

**Einfügen** direkt über `function recordSyncActivity(env, ctx, address) {`:

```js
// ANONYME BESUCHER-ZAEHLUNG (auf Wunsch).
//
// Die Adress-Statistik (sync_activity_*) zaehlt ausschliesslich Nutzer MIT eingetragener
// Wallet -- nur die rufen /purchases, /wallets, /drawings, /swap-history ueberhaupt auf. Wer
// nur Chart, Node-Karte oder Swap benutzt, taucht dort NIE auf.
//
// /volume ruft dagegen jeder Besucher auf. Die App haengt dort ein Token an, das ihr Browser
// selbst erzeugt hat (Zufallszahl im localStorage, siehe visitorToken in app.js). Daraus wird
// hier "so viele Geraete pro Tag" -- ein INSERT OR IGNORE je Geraet und Tag, also hoechstens
// ein Schreibvorgang pro Geraet und Tag.
//
// Was hier bewusst NICHT passiert: keine IP, kein Fingerprint, keine Verknuepfung mit einer
// Wallet. Das Token ist fuer niemanden ausser dem Browser selbst deutbar.
const VISITOR_TOKEN_RE = /^[A-Za-z0-9_-]{8,64}$/;

function recordVisitor(env, ctx, token) {
  if (!env.DB || !ctx || typeof ctx.waitUntil !== 'function') return;
  if (!token || !VISITOR_TOKEN_RE.test(token)) return;
  const now = Date.now();
  const day = utcDayString(now);
  ctx.waitUntil(
    env.DB
      .prepare('INSERT OR IGNORE INTO visitor_days (token, day, first_seen_at) VALUES (?, ?, ?)')
      .bind(token, day, now)
      .run()
      .catch((e) => {
        console.warn('[rune-rewards-backend] recordVisitor fehlgeschlagen (Migration ausgeführt?):', e?.message || String(e));
      })
  );
}
```

**Ersetzen** — `handleVolume` (die ganze Funktion):

```js
async function handleVolume(request, env, ctx) {
  // Besucher-Token aus der Anfrage (?v=...). Fehlt es (aeltere App-Version, privater Modus),
  // aendert sich nichts -- dann wird schlicht nicht gezaehlt.
  try {
    recordVisitor(env, ctx, new URL(request.url).searchParams.get('v'));
  } catch (e) { /* die Volumen-Antwort haengt nicht davon ab */ }
  const result = await fetchVolumeBundle(env, ctx);
  return json({ ...result.data, stale: result.stale, staleSince: result.staleSince || null }, env);
}
```

---

## Schritt 3 — Ausschluss-Liste auch beim LESEN anwenden

Bisher filterte `STATS_EXCLUDED_ADDRESSES` nur beim Schreiben. Alles, was vor dem Setzen der
Variable erfasst wurde, zählt bis heute mit — und wenn du auf zwei Geräten verschiedene erste
Wallets hast, ist nur eine ausgeschlossen.

**Einfügen** in `handleStats`, direkt nach `const day30 = ...`:

```js
  // Ausschluss-Liste auch beim LESEN anwenden -- sonst zaehlen Zeilen weiter mit, die vor dem
  // Setzen von STATS_EXCLUDED_ADDRESSES geschrieben wurden.
  const excl = [...getStatsExcludedAddresses(env)];
  const exclSql = excl.length ? ` AND LOWER(address) NOT IN (${excl.map(() => '?').join(',')})` : '';
```

Dann in den Abfragen darunter jeweils `${exclSql}` an die WHERE-Klausel hängen und `...excl` an
`bind(...)`. Konkret:

```js
env.DB.prepare(`SELECT COUNT(DISTINCT address) AS n FROM sync_activity_days WHERE 1=1${exclSql}`).bind(...excl).first(),
env.DB.prepare(`SELECT COUNT(DISTINCT address) AS n FROM sync_activity_days WHERE day >= ?${exclSql}`).bind(day1, ...excl).first(),
env.DB.prepare(`SELECT COUNT(DISTINCT address) AS n FROM sync_activity_days WHERE day >= ?${exclSql}`).bind(day7, ...excl).first(),
env.DB.prepare(`SELECT COUNT(DISTINCT address) AS n FROM sync_activity_days WHERE day >= ?${exclSql}`).bind(day30, ...excl).first(),
```

Bei der Nutzungstiefe (`depthRow`) in die innere Abfrage:

```js
         SELECT address, COUNT(DISTINCT day) AS d FROM sync_activity_days
         WHERE day >= ?${exclSql}
```
…und `.bind(day30, ...excl)`.

Bei den drei `sync_activity_counts`-Abfragen analog:

```js
env.DB.prepare(`SELECT COALESCE(SUM(count), 0) AS n FROM sync_activity_counts WHERE day >= ?${exclSql}`).bind(day1, ...excl).first()
```

---

## Schritt 4 — Besucherzahlen in die Statistik

**Einfügen** in `handleStats` im `Promise.all([...])` (als zusätzliche Einträge am Ende) und die
Rückgabewerte am Destructuring ergänzen:

```js
    // Anonyme Geraete-Zaehlung (visitor_days). Faellt weich aus, wenn die Migration noch nicht
    // gelaufen ist -- dann stehen dort Nullen statt eines Fehlers.
    env.DB.prepare('SELECT COUNT(DISTINCT token) AS n FROM visitor_days WHERE day >= ?').bind(day1).first()
      .catch(() => ({ n: null })),
    env.DB.prepare('SELECT COUNT(DISTINCT token) AS n FROM visitor_days WHERE day >= ?').bind(day7).first()
      .catch(() => ({ n: null })),
    env.DB.prepare('SELECT COUNT(DISTINCT token) AS n FROM visitor_days WHERE day >= ?').bind(day30).first()
      .catch(() => ({ n: null })),
    env.DB.prepare('SELECT COUNT(DISTINCT token) AS n FROM visitor_days').first()
      .catch(() => ({ n: null })),
    env.DB.prepare('SELECT MIN(day) AS d FROM visitor_days').first()
      .catch(() => ({ d: null })),
```

Destructuring oben entsprechend erweitern:

```js
  const [totalRow, active1Row, active7Row, active30Row, depthRow, totalRequests1Row,
         totalRequests7Row, totalRequests30Row, trackingSinceRow,
         vis1Row, vis7Row, vis30Row, visTotalRow, visSinceRow] = await Promise.all([
```

Und in das `stats`-Objekt aufnehmen:

```js
    // Anonyme Geraete-Zaehlung: zaehlt GERAETE, nicht Menschen (Handy + PC = zwei), und wer
    // Browserdaten loescht oder privat surft, zaehlt beim naechsten Besuch erneut. Die Zahl
    // faellt dadurch eher zu HOCH aus -- sie ist eine Obergrenze, keine Nutzerzahl.
    visitorsLast1d: vis1Row?.n ?? null,
    visitorsLast7d: vis7Row?.n ?? null,
    visitorsLast30d: vis30Row?.n ?? null,
    visitorsTotal: visTotalRow?.n ?? null,
    visitorsSince: visSinceRow?.d ?? null,
```

---

## Schritt 5 — Zwei Seiten zum Wischen + aktive Adressen fest auf 24 h

**Ersetzen** im HTML-Block: das `<style>`-Ende, der `<body>`-Inhalt und das `<script>`.

### CSS ergänzen (vor `</style>`)

```css
  /* Zwei Seiten nebeneinander, horizontal wischbar (Snap). Auf dem Handy wie ein Karussell,
     am PC funktioniert dieselbe Leiste mit den Punkten. */
  .pager { display: flex; overflow-x: auto; scroll-snap-type: x mandatory; gap: 0;
           scrollbar-width: none; -webkit-overflow-scrolling: touch; }
  .pager::-webkit-scrollbar { display: none; }
  .page { flex: 0 0 100%; scroll-snap-align: start; min-width: 100%; }
  .dots { display: flex; gap: 7px; justify-content: center; margin: 18px 0 0; }
  .dot-nav { width: 7px; height: 7px; border-radius: 50%; background: #1f2b35; border: none;
             padding: 0; cursor: pointer; transition: background 0.15s ease; }
  .dot-nav.active { background: #2dd4bf; }
  .page-title { font-size: 12px; color: #5f7480; margin: 0 0 12px; letter-spacing: 0.04em;
                text-transform: uppercase; }
  .note { font-size: 11px; color: #52646f; line-height: 1.5; margin-top: 14px;
          border-left: 2px solid #1f2b35; padding-left: 10px; max-width: 480px; }
```

### Body: Seiten umbauen

Die bisherige `<div class="grid">…</div>` wird zu Seite 1. Die Kachel „Aktive Adressen" verliert
ihren Umschalter:

```html
  <div class="pager" id="pager">
    <section class="page">
      <div class="page-title">Adressen (mit eingetragener Wallet)</div>
      <div class="grid">
        <div class="tile">
          <div class="tile-head">
            <div class="tile-label" style="margin-top:0">Aktive Adressen</div>
            <div class="tile-period">24h</div>
          </div>
          <div class="tile-value" id="v-active">${stats.activeLast1d}</div>
          <div class="tile-hint">Adressen, die in den letzten 24h synchronisiert haben</div>
        </div>
        <div class="tile">
          <div class="tile-head">
            <div class="tile-label" style="margin-top:0">Requests gesamt</div>
            <div class="tile-period">24h</div>
          </div>
          <div class="tile-value" id="v-requests">${stats.totalRequestsLast1d}</div>
          <div class="tile-hint">alle Sync-Aufrufe der letzten 24h, nicht Tage-dedupliziert</div>
        </div>
        ${tile('total', 'Adressen insgesamt', stats.totalUniqueAddressesEver, trackingHint)}
        ${tile('returning', 'Wiederkehrer – 30 Tage', stats.returningLast30d, '≥2 verschiedene Tage synchronisiert')}
        ${tile('rate', 'Retention-Quote', stats.retentionRate30d == null ? '—' : stats.retentionRate30d + '%', 'Anteil Wiederkehrer an aktiven Adressen (30T)')}
        ${tile('avgreq', 'Ø Requests je aktiver Adresse', stats.activeLast1d > 0 ? Math.round((stats.totalRequestsLast1d / stats.activeLast1d) * 10) / 10 : '—', 'letzte 24h, je in 24h aktiver Adresse')}
        <div class="tile wide">
          <div class="tile-label" style="margin-top:0; margin-bottom:12px;">Nutzungstiefe (letzte 30 Tage)</div>
          ${stats.engagementDepth.map(row => `
            <div class="depth-row">
              <div class="depth-label">≥ ${row.minDays} Tage</div>
              <div class="depth-bar-track">
                <div class="depth-bar-fill" id="v-depth-bar-${row.minDays}" style="width:${row.pct == null ? 0 : row.pct}%"></div>
              </div>
              <div class="depth-pct" id="v-depth-pct-${row.minDays}">${row.pct == null ? '—' : row.pct + '%'}</div>
              <div class="depth-count" id="v-depth-count-${row.minDays}">(${row.count})</div>
            </div>`).join('')}
          <div class="tile-hint" style="margin-top:8px;">Anteil der in den letzten 30 Tagen aktiven Adressen (<span id="v-depth-base">${stats.activeLast30d}</span>), die an mindestens X verschiedenen Tagen synchronisiert haben. Jede Stufe ist in der vorherigen enthalten.</div>
        </div>
      </div>
    </section>

    <section class="page">
      <div class="page-title">Besucher (anonym, alle Geräte)</div>
      <div class="grid">
        ${tile('vis1', 'Geräte – 24h', stats.visitorsLast1d, 'unterschiedliche Geräte in den letzten 24h')}
        ${tile('vis7', 'Geräte – 7 Tage', stats.visitorsLast7d)}
        ${tile('vis30', 'Geräte – 30 Tage', stats.visitorsLast30d)}
        ${tile('vistotal', 'Geräte insgesamt', stats.visitorsTotal, stats.visitorsSince ? `seit ${deDate(stats.visitorsSince)}` : 'noch keine Aufzeichnung')}
      </div>
      <div class="note">
        Gezählt werden <b>Geräte</b>, nicht Menschen: Handy und PC derselben Person sind zwei.
        Wer Browserdaten löscht oder privat surft, zählt beim nächsten Besuch erneut — die Zahl
        ist also eher eine Obergrenze. Grundlage ist eine Zufallszahl, die der Browser selbst
        erzeugt; keine IP, kein Fingerprint, keine Verknüpfung mit einer Wallet.
        <br><br>
        Der Unterschied zur ersten Seite: Dort zählen nur Nutzer <b>mit eingetragener Wallet</b>
        (nur die synchronisieren). Hier zählt jeder Besuch, auch wer nur den Chart ansieht.
      </div>
    </section>
  </div>

  <div class="dots">
    <button class="dot-nav active" data-page="0" aria-label="Seite 1"></button>
    <button class="dot-nav" data-page="1" aria-label="Seite 2"></button>
  </div>
```

### Script anpassen

`renderSelected()`: die Zeile mit `sel-active` entfällt, stattdessen fest 24 h, dazu die neuen
Werte:

```js
  function renderSelected() {
    if (!latestStats) return;
    // Aktive Adressen fest auf 24h -- "Adressen insgesamt" zeigt ohnehin den Gesamtstand.
    const requestsVal = latestStats.totalRequestsLast1d;
    const avgVal = latestStats.activeLast1d > 0
      ? Math.round((requestsVal / latestStats.activeLast1d) * 10) / 10 : null;
    const trackingHint = latestStats.trackingSince
      ? 'seit ' + deDate(latestStats.trackingSince) + ' · ' + latestStats.trackingSinceDays + ' Tage'
      : 'noch keine Aufzeichnung';

    setText('v-since', trackingHint);
    setText('h-total', trackingHint);
    setText('v-active', latestStats.activeLast1d);
    setText('v-requests', requestsVal);
    setText('v-total', latestStats.totalUniqueAddressesEver);
    setText('v-returning', latestStats.returningLast30d);
    setText('v-rate', latestStats.retentionRate30d == null ? '—' : latestStats.retentionRate30d + '%');
    setText('v-avgreq', avgVal == null ? '—' : avgVal);
    setText('v-depth-base', latestStats.activeLast30d);
    setText('v-vis1', latestStats.visitorsLast1d);
    setText('v-vis7', latestStats.visitorsLast7d);
    setText('v-vis30', latestStats.visitorsLast30d);
    setText('v-vistotal', latestStats.visitorsTotal);
    setText('h-vistotal', latestStats.visitorsSince ? 'seit ' + deDate(latestStats.visitorsSince) : 'noch keine Aufzeichnung');
    (latestStats.engagementDepth || []).forEach(row => {
      const bar = document.getElementById('v-depth-bar-' + row.minDays);
      if (bar) bar.style.width = (row.pct == null ? 0 : row.pct) + '%';
      setText('v-depth-pct-' + row.minDays, row.pct == null ? '—' : row.pct + '%');
      setText('v-depth-count-' + row.minDays, '(' + row.count + ')');
    });
  }
```

Ganz unten die Zeile

```js
  document.getElementById('sel-active').addEventListener('change', renderSelected);
```

**ersetzen** durch die Seiten-Navigation:

```js
  // Wischen zwischen den Seiten: Punkte unten springen, und beim Wischen wandert der aktive
  // Punkt mit.
  const pager = document.getElementById('pager');
  const dots = [...document.querySelectorAll('.dot-nav')];
  dots.forEach(d => d.addEventListener('click', () => {
    pager.scrollTo({ left: pager.clientWidth * Number(d.dataset.page), behavior: 'smooth' });
  }));
  pager.addEventListener('scroll', () => {
    const i = Math.round(pager.scrollLeft / Math.max(1, pager.clientWidth));
    dots.forEach((d, j) => d.classList.toggle('active', j === i));
  }, { passive: true });
```

Außerdem muss `deDate` im Worker-Scope schon vor dem HTML stehen (tut es bereits — die
Funktion wird in Schritt 5 im Body benutzt, sie ist oberhalb definiert).

---

## Nach dem Ausrollen

- Die Besucherzahlen starten bei 0 und füllen sich, sobald Nutzer die neue `app.js` geladen
  haben. Wer die alte Version im Cache hat, schickt noch kein Token — die erste Woche ist
  deshalb zu niedrig.
- Beide Zahlen werden nie übereinstimmen und sollen es auch nicht: Seite 1 zählt Wallet-Nutzer
  (adressbasiert, geräteübergreifend), Seite 2 Geräte (auch ohne Wallet).

---

## Nachtrag — Anteil Geräte mit Wallet (Migration 2, einmalig)

In der D1-Console ausführen:

```sql
ALTER TABLE visitor_days ADD COLUMN has_wallet INTEGER NOT NULL DEFAULT 0;
```

Die App hängt an `/volume` zusätzlich `w=1` an, wenn auf dem Gerät eine Wallet eingetragen ist
(nur Ja/Nein, nie die Adresse). `recordVisitor` hebt `has_wallet` pro Gerät und Tag höchstens
einmal von 0 auf 1. Ohne diese Migration fällt der Worker automatisch auf die alte Zählung
zurück, und die neuen Kacheln zeigen „—“.

Dashboard (Seite 2): „Mit Wallet – 24h“ und „Mit Wallet – 30 Tage“ = Geräte mit Wallet geteilt
durch alle Geräte im selben Zeitraum.
