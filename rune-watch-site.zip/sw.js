// rune.watch Service Worker: NUR fuer Benachrichtigungen (kein Offline-Cache, kein fetch-Handler,
// damit Updates der App nie aufgehalten werden). iPhone-Web-Apps zeigen Meldungen nur ueber
// registration.showNotification an. Antippen einer Meldung holt rune.watch nach vorn.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const ziel = (e.notification.data && e.notification.data.url) || '/';
  const hash = ziel.indexOf('#') >= 0 ? ziel.slice(ziel.indexOf('#')) : '';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(liste => {
    for (const c of liste) { if ('focus' in c) { if (hash) c.postMessage({ typ: 'rw-link', hash }); return c.focus(); } }
    return self.clients.openWindow(ziel);
  }));
});
// WEB PUSH: Meldungen vom Worker auch bei geschlossener App ({ titel, text, tag }).
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { titel: 'rune.watch', text: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.titel || 'rune.watch', { body: d.text || '', tag: d.tag || undefined, data: { url: d.url || '/' } }));
});
