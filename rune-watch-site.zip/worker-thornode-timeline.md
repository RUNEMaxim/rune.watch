# Worker-Änderung — vierte Seite „Entwicklung"

Drei Schritte. Nichts Bestehendes wird verändert, alles ist neu dazu.

---

## Schritt 1 — Migration (D1-Console, einmalig)

```sql
CREATE TABLE IF NOT EXISTS thornode_timeline_cache (
  id INTEGER PRIMARY KEY,
  payload TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
```

Eine einzige Zeile (`id = 1`), genau wie `volume_cache` und `dex_volume_cache`.

---

## Schritt 2 — Code einfügen

**Einfügen direkt über `const MEMOLESS_UPSTREAM_DEFAULT = ...`** (also vor dem Memoless-Block,
am Ende der Handler-Sammlung):

```js
// ── ENTWICKLUNGSSTAND VON THORCHAIN (GitLab + Netz-Version) ──────────────────
//
// THORNode wird auf GitLab entwickelt; das GitHub-Repo ist nur ein Spiegel. Hier werden
// Releases, Merge Requests und Meilensteine geholt, auf das Nötige eingedampft und für
// 15 Minuten abgelegt.
//
// Warum über den Worker und nicht direkt aus dem Browser: sonst teilt sich jeder Besucher
// GitLabs Rate-Limit nach IP, und wir wären darauf angewiesen, dass GitLab für diese
// Endpunkte CORS erlaubt. So gibt es genau EINEN Abrufer, und der Token bleibt serverseitig.
//
// Dazu kommt die im Netz AKTIVE Version aus /thorchain/version. THORChain schaltet eine neue
// Version erst frei, wenn die Supermajorität der Nodes sie fährt -- die Lücke zwischen
// "im Repo fertig" und "im Netz live" ist die eigentliche Aussage dieser Seite.
const GITLAB_API = 'https://gitlab.com/api/v4/projects/thorchain%2Fthornode';
const TIMELINE_FRESH_MS = 15 * 60 * 1000;
const TIMELINE_STALE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

async function gitlabJson(env, pfad) {
  // Der Token ist OPTIONAL. Ohne ihn funktioniert alles, nur mit knapperem Limit -- lege in
  // den Worker-Variablen GITLAB_TOKEN an (Read-only, Scope read_api), wenn es eng wird.
  const tok = env && env.GITLAB_TOKEN;
  const res = await fetchWithTimeout(`${GITLAB_API}${pfad}`, {
    timeoutMs: 12000,
    headers: {
      'x-client-id': 'rune-rewards-backend',
      ...(tok ? { 'PRIVATE-TOKEN': tok } : {}),
    },
  });
  if (!res.ok) throw new Error(`GITLAB_HTTP_${res.status} (${pfad})`);
  return res.json();
}

const alsMs = (s) => { const t = s ? Date.parse(s) : NaN; return Number.isFinite(t) ? t : null; };

function mrKompakt(m) {
  return {
    iid: m && m.iid,
    titel: String((m && m.title) || '').slice(0, 160),
    autor: (m && m.author && m.author.name) || null,
    datumMs: alsMs((m && (m.merged_at || m.updated_at)) || null),
    url: (m && m.web_url) || null,
  };
}

async function baueThornodeTimeline(env) {
  const [relR, tagR, mergedR, offenR, meilenR, versionR] = await Promise.allSettled([
    gitlabJson(env, '/releases?per_page=15'),
    gitlabJson(env, '/repository/tags?per_page=25'),
    gitlabJson(env, '/merge_requests?state=merged&order_by=updated_at&sort=desc&per_page=30'),
    gitlabJson(env, '/merge_requests?state=opened&order_by=updated_at&sort=desc&per_page=20'),
    gitlabJson(env, '/milestones?state=active&per_page=10'),
    fetchFromBases(getThornodeBases(), '/thorchain/version'),
  ]);

  const w = (r) => (r.status === 'fulfilled' && r.value) || null;

  // Releases bevorzugt aus /releases; wenn dort nichts steht (THORChain taggt nicht immer
  // über die Release-Funktion), aus den Tags. Sonst bliebe die Hauptansicht leer.
  let releases = [];
  const rel = w(relR);
  if (Array.isArray(rel) && rel.length) {
    releases = rel.map((r) => ({
      version: r.tag_name || r.name || null,
      datumMs: alsMs(r.released_at || r.created_at),
    }));
  } else {
    const tags = w(tagR);
    if (Array.isArray(tags)) {
      releases = tags.map((t) => ({
        version: t.name || null,
        datumMs: alsMs(t.commit && (t.commit.created_at || t.commit.committed_date)),
      }));
    }
  }
  releases = releases.filter((r) => r.version).sort((a, b) => (b.datumMs || 0) - (a.datumMs || 0));

  const ver = w(versionR);
  const netzVersion = (ver && (ver.current || ver.next)) || null;

  const meilen = w(meilenR);

  return {
    netzVersion,
    releases,
    merged: (w(mergedR) || []).map(mrKompakt),
    offen: (w(offenR) || []).map(mrKompakt),
    meilensteine: (Array.isArray(meilen) ? meilen : []).map((m) => ({
      titel: String((m && m.title) || '').slice(0, 120),
      url: (m && m.web_url) || null,
    })),
    fetchedAt: Date.now(),
  };
}

async function handleThornodeTimeline(request, env, ctx) {
  // Erst der Cache: er entscheidet, ob überhaupt jemand GitLab anfassen muss.
  let zeile = null;
  try {
    zeile = await env.DB.prepare('SELECT payload, updated_at FROM thornode_timeline_cache WHERE id = 1').first();
  } catch (e) {
    console.warn('[rune-rewards-backend] thornode_timeline_cache nicht lesbar (Migration ausgeführt?):', e?.message || String(e));
  }
  if (zeile && zeile.payload && (Date.now() - zeile.updated_at) < TIMELINE_FRESH_MS) {
    try { return json({ ...JSON.parse(zeile.payload), stale: false }, env); } catch (e) { /* neu holen */ }
  }

  try {
    const daten = await baueThornodeTimeline(env);
    // Nur ablegen, wenn wirklich etwas drinsteht -- sonst überschreibt ein kurzer GitLab-
    // Ausfall einen brauchbaren Cache mit einer leeren Hülle.
    const brauchbar = daten.releases.length || daten.merged.length || daten.netzVersion;
    if (!brauchbar) throw new Error('TIMELINE_EMPTY');
    const schreiben = env.DB.prepare(
      `INSERT INTO thornode_timeline_cache (id, payload, updated_at) VALUES (1, ?, ?)
       ON CONFLICT(id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at`
    ).bind(JSON.stringify(daten), Date.now()).run().catch((e) => {
      console.warn('[rune-rewards-backend] thornode_timeline_cache-Schreiben fehlgeschlagen:', e?.message || String(e));
    });
    if (ctx && ctx.waitUntil) ctx.waitUntil(schreiben); else await schreiben;
    return json({ ...daten, stale: false }, env);
  } catch (e) {
    console.warn('[rune-rewards-backend] /thornode-timeline fehlgeschlagen, versuche Stale-Cache:', e?.message || String(e));
    if (zeile && zeile.payload && (Date.now() - zeile.updated_at) < TIMELINE_STALE_MAX_AGE_MS) {
      try { return json({ ...JSON.parse(zeile.payload), stale: true, staleSince: zeile.updated_at }, env); } catch (e2) { /* fällt durch */ }
    }
    return json({ error: 'TIMELINE_UNAVAILABLE', message: e?.message || String(e) }, env, 503);
  }
}
```

---

## Schritt 3 — Route eintragen

**Einfügen** im `fetch`-Handler, direkt über der Zeile `if (url.pathname === '/stats') {`:

```js
      if (url.pathname === '/thornode-timeline') {
        return await handleThornodeTimeline(request, env, ctx);
      }
```

---

## Prüfen

```
curl -s https://rune-rewards-backend.maxkalinowski.workers.dev/thornode-timeline | head -c 400
```

Erwartet: `netzVersion`, `releases`, `merged`, `offen`, `meilensteine`.
Beim zweiten Aufruf kommt die Antwort aus dem Cache und ist sofort da.
