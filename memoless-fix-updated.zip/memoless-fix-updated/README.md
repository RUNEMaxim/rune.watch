# Änderungen in diesem Paket

## 1. FIX 23 — "Top Swap Pairs" zeigte falsches 24h-Volumen

**Problem:** Die alte `last_height`-Nachlauf-Logik im Worker versuchte, lückenlos alle Swaps
seit dem letzten Cron-Durchlauf zu erfassen und ein "echtes" 24h/7d/30d-Fenster zu behaupten.
Passierten zwischen zwei Durchläufen mehr als 500 Swaps (bei aktivem Netzwerk üblich), blieb
der Fortschritt absichtlich stehen — die Tabelle deckte dauerhaft nur wenige Stunden statt der
behaupteten 24h ab, ohne dass das im UI erkennbar war.

**Fix:** Kompletter Strategiewechsel — statt eines behaupteten Zeitfensters werden jetzt immer
die neuesten 1.000 Swaps gehalten (`SWAP_COLLECT_PAGES = 20`, `SWAP_EVENTS_KEEP = 1000`).
`/top-pairs` liefert zusätzlich `swapCount`/`spanFromMs`/`spanToMs`, damit das Frontend ehrlich
anzeigt: "Letzte 1.000 Swaps · deckt die letzten X ab" statt einer festen 24h/7d/30d-Beschriftung.

**Betroffene Dateien:**
- `worker.js` (separat bereitgestellt, nicht in dieser ZIP — siehe Chat) — `collectSwapPairStats()`, `handleTopPairs()` komplett überarbeitet
- `app.js` — Modal-State (`topPairsWindow` entfernt), Fetch (kein `window`-Parameter mehr),
  UI (24h/7d/30d-Tabs entfernt, dynamische Spannenanzeige eingebaut über neue
  `fmtDurationSpan()`-Hilfsfunktion und `topPairsSpanPrefix`/`topPairsSpanSuffix`-Labels)

**Manuell zu erledigen:**
1. Den Inhalt von `worker.js` (separate Datei im Chat) in den Cloudflare-Dashboard-Editor kopieren und deployen.
2. Keine neue D1-Migration nötig — `swap_events`/`recent_swaps_snapshot` bleiben unverändert.
   `swap_collector_state` wird nicht mehr benutzt, kann aber unverändert in D1 stehen bleiben
   (kein Löschen nötig).
3. Nach dem Deploy dauert es einen Cron-Zyklus, bis `swap_events` erstmals nach neuer Logik
   befüllt wird.

## 2. Churn-Countdown-Timer war berechnet, aber nirgends sichtbar

**Problem:** `fetchChurnCountdown()` berechnete bereits `nextChurnEstimateMs` (wann der nächste
Churn ungefähr stattfindet), und die Formatierungsfunktion `fmtCountdown()` existierte fertig —
wurde aber im gesamten Code nie aufgerufen. Im UI war nur der "Churning pausiert"-Hinweis
verdrahtet, der Countdown selbst fehlte komplett.

**Fix:** Im "Next Reward"-Kachel-Header wird jetzt, wenn Churning NICHT pausiert ist und
`nextChurnEstimateMs` vorhanden ist, "Nächster Churn in Xh Ym" angezeigt (mit der bereits
vorhandenen `fmtCountdown()`-Funktion, inkl. aller 10 Sprachen). Die Anzeige zählt automatisch
mit herunter, da die Komponente ohnehin sekündlich neu rendert (`smoothTick`).

**Betroffene Dateien:**
- `app.js` — neue Übersetzung `nextChurnInLabel` (10 Sprachen), JSX-Bedingung um
  `nextRewardForecast.halted` erweitert (halted-Badge ODER Countdown, nie beides)

**Manuell zu erledigen:** Keine — reine Frontend-Änderung, kein Worker-/DB-Bezug.

## Dateien in diesem Paket

```
app.js                         — gepatchtes Frontend (beide Fixes)
index.html
react.production.min.js
react-dom.production.min.js
```

Der aktualisierte Cloudflare Worker (`worker.js`, FIX 23) ist separat im Chat bereitgestellt,
nicht in dieser ZIP.
